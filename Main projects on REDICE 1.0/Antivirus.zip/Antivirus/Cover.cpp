﻿#include <iostream>
#include <string>
//#include <fstream>
//#include <newcpp>
#include "Antivirus.h"

using namespace std;
using namespace basic;

int main(int argc, char** argv) {
    Initialize(); //Load virus database
    string s;

    //Debugging console.
    while (true) {
        cout << "> ";
        getline(cin, s); //cin >> s;
        UpStr(s);
        if (s == "ADD") {
            cin >> s;
            AddVirus(s, ReadSource(s));
        }
        else if (s == "SAVE")
            SaveDatabase();
        else if (UpperString(s) == "INITIALIZE")
            Initialize();
        else
            Scan(s);
    }
}

/*
    Info:
    1) Can save new viruses to database.
    2) Can scan files and check it by signature.
    3) Antivirus is vulnerable, by changing database file or making code, process, or value/variable injection.

    Needs to make:
    1) Monitoring processes.
    2) Check all system and simple files.
    3) Check all started, downloaded, moved, copied programs.
*/

// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.
