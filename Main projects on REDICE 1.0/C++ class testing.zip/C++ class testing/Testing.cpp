﻿#include <iostream>
#include <string>
#include <vector>
#include <stdio.h>
#include <ctype.h>
#include <sstream>

using namespace std;

//vector<char> str;

string Up(string s) {
    string res = s;
    for (int i = 0; i < s.length(); i++)
        res[i] = toupper(s[i]);
    return res;
}
    
string Low(string s) {
    string res = s;
    for (int i = 0; i < s.length(); i++)
        res[i] = tolower(s[i]);
    return res;
}
    
int Module(int n) {
    if (n < 0)
        return 0 - n;
    return n;
}
    
int CharLength(const char* s) {
    return (unsigned)strlen(s);
}

//class newstr {
//private:
//    char* data;    /*!< The ASCII characters that comprise the newstr */
//    unsigned length;  /*!< The number of characters allocated in data */
//public:
//    /*!
//     *  @brief Empty newstr Constructor.
//     *  @post newstr length is set equal to 0.
//     */
//    newstr();
//
//    /*!
//     *  @brief Single-character newstr Constructor.
//     *  @param[in] c A char literal.
//     *  @post newstr data equals @a c and newstr length equals 1.
//     */
//    newstr(char c);
//
//    /*!
//     *  @brief char* newstr Constructor
//     *  @param[in] c A char* null-terminated newstr.
//     *  @post newstr length equals @code{.cpp}strlen(c)@endcode.
//     *  @post newstr data equals @a c allocated values, except the null-terminator.
//     */
//    newstr(const char* c);
//
//    /*!
//     *  @brief Copy newstr Constructor
//     *  @param[in] s A newstr instance.
//     *  @post This newstr will be identical to newstr @a s.
//     */
//    newstr(const newstr& s);
//
//    /*!
//     *  @brief Default newstr Destructor
//     *  @post newstr data is deleted.
//     */
//    ~newstr();
//
//    /*!
//     *  @brief newstr length.
//     *  @return Value in newstr @c length.
//     */
//    unsigned len() const;
//
//    /*!
//     *  @brief newstr index of @a c.
//     *  @param[in] c A char literal.
//     *  @return The index of @a c in newstr, if exists; -1 otherwise.
//     */
//    int index(char c) const;
//
//    /*!
//     *  @brief Converts lowercase alphabetic characters to uppercase.
//     *  @param[in] first Starting index of newstr to change case.
//     *  @param[in] last  Ending index of newstr to change case.
//     *  @pre @a first is less than or equal to @a last and @a last is less than
//     *       or equal to newstr length.
//     *  @post All lowercase alphabetic characters in newstr data greater than
//     *        or equal to @a first, but less than @a last are uppercase.
//     *  @throw int
//     */
//    void upcase(unsigned first, unsigned last);
//
//    /*!
//     *  @brief Converts uppercase alphabetic characters to lowercase.
//     *  @param[in] first Starting index of newstr to change case.
//     *  @param[in] last Ending index of newstr to change case.
//     *  @pre @a first is less than or equal to @a last and @a last is less than
//     *       or equal to newstr length.
//     *  @post All uppercase alphabetic characters in newstr data greater than
//     *        or equal to @a first, but less than @a last are lowercase.
//     *  @throw int
//     */
//    void downcase(unsigned first, unsigned last);
//
//    /*!
//     *  @brief Toggles lowercase alphabetic characters to uppercase, and vice versa.
//     *  @param[in] first Starting index of newstr to change case.
//     *  @param[in] last  Ending index of newstr to change case.
//     *  @pre @a first is less than or equal to @a last and @a last is less than
//     *       or equal to newstr length.
//     *  @post All lowercase alphabetic characters in newstr data greater than
//     *        or equal to @a first, but less than @a last are uppercase, and
//              all uppercase alphabetic characters in newstr data are lowercase.
//     *  @throw int
//     */
//    void togglecase(unsigned first, unsigned last);
//
//    //@{
//    /*!
//     *  @brief Stream operators.
//     *  @param so A stream object.
//     *  @param s  A newstr object.
//     *  @return Stream object containing newstr content.
//     */
//    friend std::ostream& operator<< (std::ostream& so, const newstr& s);
//    friend std::istream& operator>> (std::istream& so, newstr& s);
//    //@}
//
//    //@{
//    /*!
//     *  @brief Access newstr character.
//     *  @param j Index value in newstr.
//     *  @pre @a j is less than newstr length.
//     *  @return character at @a j index of newstr data.
//     *  @throw int
//     */
//    char  operator[] (unsigned j) const;
//    char& operator[] (unsigned j);
//    //@}
//
//    /*!
//     *  @brief Sets newstr value.
//     *  @param[in] s A newstr object.
//     *  @return A newstr reference to *this.
//     *  @post newstr will be equivalent to @a s.
//     */
//    newstr& operator= (const newstr& s);
//
//    /*!
//     *  @brief Append to newstr.
//     *  @param[in] s A newstr object.
//     *  @return A newstr reference to *this.
//     *  @post newstr will equal the concatenation of itself with @a s.
//     */
//    newstr& operator+= (const newstr& s);
//
//    //@{
//    /*!
//     *  @brief newstr concatenation (addition).
//     *  @param[in] lhs The left-hand operand newstr or newstr convertable.
//     *  @param[in] rhs The right-hand operand newstr or newstr convertable.
//     *  @return Copy of a newstr object.
//     *  @post The newstr will be the concatenation of @a lhs and @a rhs.
//     */
//    friend newstr operator+ (const newstr& lhs, const newstr& rhs);
//    friend newstr operator+ (const newstr& lhs, char          rhs);
//    friend newstr operator+ (const newstr& lhs, const char* rhs);
//    friend newstr operator+ (char          lhs, const newstr& rhs);
//    friend newstr operator+ (const char* lhs, const newstr& rhs);
//    //@}
//
//    //@{
//    /*!
//     *  @brief newstr equality
//     *  @param[in] lhs The left-hand operand newstr or newstr convertable.
//     *  @param[in] rhs The right-hand operand newstr or newstr convertable.
//     *  @return True, if @a lhs and @a rhs have the same length, and each
//     *          character in their newstr data are identical in both value
//     *          and index.
//     */
//    friend bool operator== (const newstr& lhs, const newstr& rhs);
//    friend bool operator== (const newstr& lhs, char          rhs);
//    friend bool operator== (const newstr& lhs, const char* rhs);
//    friend bool operator== (char          lhs, const newstr& rhs);
//    friend bool operator== (const char* lhs, const newstr& rhs);
//    //@}
//
//    //@{
//    /*!
//     *  @brief newstr inequality: Greater-than.
//     *  @param[in] lhs The left-hand operand newstr or newstr convertable.
//     *  @param[in] rhs The right-hand operand newstr or newstr convertable.
//     *  @return True, if @a lhs is in dictionary order (Capitals-first) to
//     *          @a rhs when comparing alphabetical characters or @a lhs is
//     *          greater in ASCII value to @a rhs, in corresponding newstr
//     *          data indices.
//     */
//    friend bool operator> (const newstr& lhs, const newstr& rhs);
//    friend bool operator> (const newstr& lhs, char          rhs);
//    friend bool operator> (const newstr& lhs, const char* rhs);
//    friend bool operator> (char          lhs, const newstr& rhs);
//    friend bool operator> (const char* lhs, const newstr& rhs);
//    //@}
//
//    //@{
//    /*!
//     *  @brief newstr non-equality
//     *  @param[in] lhs The left-hand operand newstr or newstr convertable.
//     *  @param[in] rhs The right-hand operand newstr or newstr convertable.
//     *  @return True, if @a lhs is not equal to @a rhs.
//     *  @see newstr::operator==
//     */
//    friend bool operator!= (const newstr& lhs, const newstr& rhs);
//    friend bool operator!= (const newstr& lhs, char          rhs);
//    friend bool operator!= (const newstr& lhs, const char* rhs);
//    friend bool operator!= (char          lhs, const newstr& rhs);
//    friend bool operator!= (const char* lhs, const newstr& rhs);
//    //@}
//
//    //@{
//    /*!
//     *  @brief newstr inequality: Less-than.
//     *  @param[in] lhs The left-hand operand newstr or newstr convertable.
//     *  @param[in] rhs The right-hand operand newstr or newstr convertable.
//     *  @return True, if @a lhs is neither equal to, nor greater-than @a rhs.
//     *  @see newstr::operator==,newstr::operator>
//     */
//    friend bool operator< (const newstr& lhs, const newstr& rhs);
//    friend bool operator< (const newstr& lhs, char          rhs);
//    friend bool operator< (const newstr& lhs, const char* rhs);
//    friend bool operator< (char          lhs, const newstr& rhs);
//    friend bool operator< (const char* lhs, const newstr& rhs);
//    //@}
//
//    //@{
//    /*!
//     *  @brief newstr inequality: Less-than or equal
//     *  @param[in] lhs The left-hand operand newstr or newstr convertable.
//     *  @param[in] rhs The right-hand operand newstr or newstr convertable.
//     *  @return True, if @a lhs is not greater-than @a rhs.
//     *  @see newstr::operator>
//     */
//    friend bool operator<= (const newstr& lhs, const newstr& rhs);
//    friend bool operator<= (const newstr& lhs, char          rhs);
//    friend bool operator<= (const newstr& lhs, const char* rhs);
//    friend bool operator<= (char          lhs, const newstr& rhs);
//    friend bool operator<= (const char* lhs, const newstr& rhs);
//    //@}
//
//    //@{
//    /*!
//     *  @brief newstr inequality: Greater-than or equal
//     *  @param[in] lhs The left-hand operand newstr or newstr convertable.
//     *  @param[in] rhs The right-hand operand newstr or newstr convertable.
//     *  @return True, if @a lhs is greater-than or equal to @a rhs.
//     *  @see newstr::operator>,newstr::operator==
//     */
//    friend bool operator>= (const newstr& lhs, const newstr& rhs);
//    friend bool operator>= (const newstr& lhs, char          rhs);
//    friend bool operator>= (const newstr& lhs, const char* rhs);
//    friend bool operator>= (char          lhs, const newstr& rhs);
//    friend bool operator>= (const char* lhs, const newstr& rhs);
//    //@}
//};

class newstr {
private:
    char *str;
    unsigned int length;
public:
    const unsigned int &len = length;
    unsigned int Length() const {
        return length;
    }

    newstr() {
        str = new char[0];
    }
    newstr(char c) {
        str = new char(c);
        length = 1;
    }
    newstr(const char* s) {
        //length = strlen(s);
        for (length = 0; s[length] != '\0'; length++);
        str = new char[length];
        for (int i = 0; i < length; i++)
            str[i] = s[i];
    }

    /*newstr::~newstr() {
        delete[] str;
    }*/

    char& operator[](int index) const {
        if (index > length || index < 0)
            throw "Incorrect index.";
        return str[index];
    }
    /*char operator[](int index) const {
        if (index > length || index < 0)
            throw "Incorrect index.";
        return str[index];
    }
    char& operator[](unsigned int index) {
        if (index > length || index < 0)
            throw "Incorrect index.";
        return str[index];
    }*/

    void operator=(const char* s) {
        for (length = 0; s[length] != '\0'; length++);
        str = new char[length];
        for (int i = 0; i < length; i++)
            str[i] = s[i];
    }
    void operator=(const newstr& s) {
        for (length = 0; s[length] != '\0'; length++);
        str = new char[length];
        for (int i = 0; i < length; i++)
            str[i] = s[i];
    }

    newstr& operator+=(const newstr& s) {
        unsigned int l = length + s.len;
        char* res = new char[length];
        for (int i = 0; i < length; i++)
            res[i] = str[i];
        for (int i = length; i < l; i++)
            res[i] = s[i];

        delete[] res; //WARNING: May be useless.
        length = l;
        str = res;
        return *this;
    }

    newstr operator+(const newstr& s) {
        newstr newStr(*this);
        newStr += s;
        return newStr;
    }

    bool operator==(const newstr& s) {
        if (s.len != length)
            return false;
        for (unsigned int i = 0; i < s.len; i++) 
            if (str[i] != s[i]) return false;
        return true;
    }

    friend std::ostream& operator<<(std::ostream& os, const newstr& s) {
        for (unsigned int i = 0; i < s.Length(); i++)
            os << s[i];
        
        return os;
    }
    friend std::istream& operator>>(std::istream& is, const newstr& s) {
        try {
            char* S = new char[3000];
            is >> S;
            newstr s(S);
            delete[] S;

            return is;
        }catch (...) {
            throw "Buffer overflow.";
        }
    }
};

template<class T>
class matrix {
private:
    T* arr;
public:
    matrix() {
        T* arr;
    }
    matrix(int size...) {
        cout << size;
    }
};

//template <typename ts, class tk>
//ts Encrypt(ts s, tk key) {
//    for (int i = 0; i < s.length(); i++)
//        s[i] += key;
//    return s;
//}
//
//newstr XOR(newstr s, const char key[]) {
//    for (int i = 0; i < s.length(); i++)
//        s[i] = s[i] ^ key[i % sizeof(key) / sizeof(char)];
//    return s;
//}

/*template<class T>
class Array {
    T* arr;
    unsigned int length;

    void Define(const unsigned int l) {
        arr = new T[l];
        length = l;
    }
public:
    const unsigned int &len = length;
    Array() {
        Define(0);
    }
    Array(const T *a, const unsigned int l) { //(T, int l) {
        Define(l);
        for (int i = 0; i < l; i++)
            arr[i] = a[i];
    }

    void MakeSize(const unsigned int l) {
        Define(l);
    }

    T& operator[](unsigned int id) const {
        if (id > length || id < 0)
            return arr[id];
        //else
            //throw "Incorrect index.";
    }
};*/

#include <vector>

template <class Type>
class List{
private:
    vector<Type> keys;
    vector<Type> values;

    unsigned int len;
public:
    const unsigned int *length = &len;

    List() {
        keys.clear();
        values.clear();
    }
    List(vector<Type> inpKeys, vector<Type> inpValues) {
        if (inpKeys.empty() || inpValues.empty()) return;
        if (inpKeys.size() != inpValues.size()) throw "Error: incorrect vectors.";

        keys = inpKeys;
        values = inpValues;
    }

    const unsigned int operator[](unsigned int id) {
        if (id >= len || id < 0)
            throw "Error: incorrect index.";
        return keys[id];
    }

    /*const Type operator[](Type key) {
        for (unsigned int i = 0; i < len; i++)
            if (keys[i] == key)
                return values[i];
        
        len++;
        keys.resize(len);
        values.resize(len);

        keys[len - 1] = key;
        return values[len - 1];
    }*/

    const bool KeyExist(Type key) {
        for (unsigned int i = 0; i < len; i++)
            if (keys[i] == key)
                return true;
    }

    const Type operator[](Type key) {
        for (unsigned int i = 0; i < len; i++)
            if (keys[i] == key)
                return values[i];
        //throw "Error: incorrect index.";
    }
};

//Why functions that doesent returned anything but needs to, result is not a chunk, but last value.
template<class RT>
const RT GetRandom() {
    if ("Hello" == "Hi") return RT("Hi");
}

//#include "Source.cpp"
int main() {
    vector<int> dates;
    vector<int> happenings;

    dates.push_back(123);
    happenings.push_back(321);

    List<int> list(dates, happenings);
    //string a = "as";
    //cout << GetRandom<string>();
    //int a[3] = {1, 2, 3};
    //Array<int> arr(a, 3);
    ////arr[0] = 4;
    ////arr.MakeSize(a);
    //try {
    //    cout << arr[10];
    //}catch (const char *e) {
    //    cerr << "Error: " << e;
    //}
}

/*
Debug status:
[+] Constructor const char(tested as string.c_str())
[+] Constructor string

[+] Operator= string.c_str()
[+] Operator= string

[+] Operator== const char*
[+] Operator== string

[+] Operator+= string.c_str()
[+] Operator+= string
[+] Operator+= char

[+] Operator+ const char*
[+] Operator+ string
[+] Operator+ char

[+] Translate to const char* (Warning: using class string)
[+] Translate to string

[+] Operator<< using class string 

[+] Operator- to const char*
[+] Operator- to string

[+] Operator-= to const char*
[+] Operator-= to string

[-] Operator* to const char*
[-] Operator* to string

Notes:
*Better write (newstr == string) then (string == newstr);
*To use string class functions better to use AsString() or LikeString();
*Operators < and > made in newstr for comparing string length. To know if length of 2 strings are equal, (var == var2) incorrect, correct is (var % var2);
*/

//matrix<int> m(1, 2, 3);
    /*newstr s("Hi! How are you?");

    try {
        cout << "\"" << s[1] << "\"";
    }catch (const char* e) {
        cerr << "Error: " << e;
    }*/
    /*cout << XOR("5CA7CO", "OBA, OTI, SAC, ATR, NAR, DAD, IBA, AHO, TIA, HDA") << endl;
    NUM n(7);
    cout << (int)n << endl;
    newstr s = "Hello";
    newstr name = "Man";

    if (s.AnyContain("hello"))
        s -= "Hello";
    if (s > name)
        cout << s << ", " << name;
    else if (s < name)
        cout << name << ", " << s;
    else if(s % name)
        cout << s << " " << name << ", " << s;*/