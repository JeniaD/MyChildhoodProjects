//#ifndef NEWCPP
//    #define NEWCPP
//
//    #include <iostream>
//    #include <windows.h>
//    #include <string>
//    #include <ctype.h>
//    #include <stdio.h>
//    #include <fstream>
//    #include <cctype>
//    #include <algorithm>
//    #include <time.h>
//    #include <sstream>
//    //#include <dirent.h>
//    //#include <winable.h>
//
//    //for "DirExist"
//    #include <sys/stat.h>
//     //#include <shlwapi.h>
//    //#pragma comment (lib, "shlwapi")
//
//    #include <vector>
//
//    using namespace std;
//
//    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
//
//    const int fileInitializeStartTime = (int)time(0);
//    #define STARTTIME fileInitializeStartTime
//
//    #define REDCONSOLE 4
//    #define GREENCONSOLE 2
//    #define YELLOWCONSOLE 14
//
//    #ifdef _WIN32
//        #include <io.h>
//        #define access _access_s
//    #else
//        #include <unistd.h>
//    #endif
//
//    //Gives true if folder exist.
//    bool DirExist(const string& path) {
//        struct stat buffer;
//        return (stat(path.c_str(), &buffer) == 0); //return PathFileExists(path.c_str());
//    }
//
//    //Returns string converted to wstring.
//    wstring StringToWString(const string s) {
//        std::wstring wsTmp(s.begin(), s.end());
//        return wsTmp;
//    }
//
//    LPCWSTR s2ws(const std::string& s) {
//        int len;
//        int slength = (int)s.length() + 1;
//        len = MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, 0, 0);
//        wchar_t* buf = new wchar_t[len];
//        MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, buf, len);
//        std::wstring r(buf);
//        delete[] buf;
//        //return r;
//
//        std::wstring stemp = s2ws(s);
//        return stemp.c_str();
//    }
//
//    //Returns string converted to LPSTR
//    LPSTR StrToLPSTR(string s) {
//        return const_cast <char*> (s.c_str());
//    }
//
//    //Returns true if given char is number
//    bool isCharNumber(char c) {
//        //int a = 100;
//        //a = c - '0';
//        return isdigit(c);
//    }
//
//    //Deleting all given chars from string and returns it.
//    string DeleteAllChars(string s, char c) {
//        s.erase(std::remove(s.begin(), s.end(), c), s.end());
//        /*for(int i = 0; i < s.length(); i++)
//          if(s[i] == c)
//              s[i] = '\0';*/
//        return s;
//    }
//
//    //Deleting chars from first parameter that are in second.
//    string DeleteAllChars(string s, string chars) {
//        for (int i = 0; i < chars.length(); i++)
//            s = DeleteAllChars(s, chars[i]);
//        return s;
//    }
//
//    /*Replacing string in text to another string. Not fully tested.
//    Usage:
//    ReplaceAll(string("Hi and hi"), std::string(" "), std::string("_"))
//    Returns:
//    "Hi_and_hi"*/
//    string ReplaceAll(std::string str, const std::string& from, const std::string& to) {
//        size_t start_pos = 0;
//        while ((start_pos = str.find(from, start_pos)) != std::string::npos) {
//            str.replace(start_pos, from.length(), to);
//            start_pos += to.length(); // Handles case where 'to' is a substring of 'from'
//        }
//        return str;
//    }
//
//    //Returns a chracter table length.
//    int CharacterTableLength() {
//        char a = 'a' + 1;
//        int counter = 1;
//        while (a != 'a') {
//            a++;
//            counter++;
//        }
//
//        return counter;
//    }
//
//    //Returns string to uppercase
//    string UpperString(string s) {
//        transform(s.begin(), s.end(), s.begin(), ::toupper);
//        return s;
//    }
//
//    //Changes the string to uppercase
//    void UpStr(string& s) {
//        transform(s.begin(), s.end(), s.begin(), ::toupper);
//    }
//
//    template < typename T >
//    string NumberToString(T pNumber) {
//        ostringstream oOStrStream;
//        oOStrStream << pNumber;
//        return oOStrStream.str();
//    }
//
//    template < class element, class container >
//    bool PartOfArray(element elem, container array) {
//        for (int i = 0; i < sizeof(array) / sizeof(array[0]); i++)
//            if (elem == array[i])
//                return true;
//
//        return false;
//    }
//
//    //Returns true if __access_s function returns 0 (~file exists)
//    bool FileExists(const std::string& Filename) {
//        return _access(Filename.c_str(), 0) == 0;
//    }
//
//    //Printing text with setted color
//    void Print(string s, int color) { //12, 4 - red; 2, 10 - green; 15 - maybe black; 14 - yellow
//        SetConsoleTextAttribute(hConsole, color);
//        cout << s;
//        SetConsoleTextAttribute(hConsole, 15); //2);
//    }
//
//    //Printing char with setted color
//    void Print(char s, int color) { //12, 4 - red; 2, 10 - green; 15 - maybe black; 14 - yellow
//        SetConsoleTextAttribute(hConsole, color);
//        cout << s;
//        SetConsoleTextAttribute(hConsole, 15); //2);
//    }
//
//    //Writes each symbol in string with function Sleep
//    void Write(string s, int maxTime) {
//        srand(time(0));
//        for (int i = 0; i < s.length(); i++) {
//            cout << s[i];
//            Sleep(rand() % maxTime);
//        }
//    }
//
//    //Writes string in setted color with Sleep.
//    void RealisticPrint(string s, int color, int maxT) {
//        SetConsoleTextAttribute(hConsole, color);
//        Write(s, maxT);
//        SetConsoleTextAttribute(hConsole, 15);
//    }
//
//    //Changing console text color. For changing it back, ChangeColor(15) or SetDefaultColor
//    void ChangeColor(int color) {
//        SetConsoleTextAttribute(hConsole, color); //15 - is back
//    }
//
//    //Setting standart color
//    void SetDefaultColor() {
//        SetConsoleTextAttribute(hConsole, 15);
//    }
//
//    //Simulating user press
//    void Press(BYTE key) {
//        keybd_event(key, 0, 0, 0);
//        keybd_event(key, 0, KEYEVENTF_KEYUP, 0);
//    }
//
//    //Simulating 2 presses
//    void DoublePress(BYTE key, BYTE key2) {
//        keybd_event(key, 0, 0, 0);
//        keybd_event(key2, 0, 0, 0);
//
//        keybd_event(key, 0, KEYEVENTF_KEYUP, 0);
//        keybd_event(key2, 0, KEYEVENTF_KEYUP, 0);
//    }
//
//    //Class for bruteforcing.
//    class Chance {
//    private:
//        const char zero = 1;
//        const char nine = 0;
//
//        string s = "";
//
//        void PlusPlus() {
//            int a = 0;
//            while (true) {
//                if (a > s.length()) {
//                    s += zero;
//                    break;
//                }
//                else if (s[a] == nine) {
//                    s[a] = zero;
//                    a++;
//                }
//                else {
//                    s[a]++;
//                    break;
//                }
//            }
//        }
//    public:
//        //Give next string guess
//        string GiveNextGuess() {
//            PlusPlus();
//            return s;
//        }
//
//        //Setting start length of brute-force string. Can be given as normal(parameter 2 but s is maybe ['', ''])
//        void SetStartLength(int l) {
//            if (l <= 0)
//                return;
//            s.clear();
//            for (int i = 0; i < l; i++)
//                s += zero;
//        }
//    };
//#endif


//class newstr {
//private:
//    vector<char> str;
//
//    string status = "sd"; //show/hide; empty/destroy;
//    void GiveError(string s) {
//        if (!ShowStatus("errorLog")) {
//            errorLog += s + ";\n";
//            return;
//        }
//        cout << s;
//        _STL_REPORT_ERROR(s);
//    }
//
//    string Up(string s) {
//        string res = s;
//        for (int i = 0; i < s.length(); i++)
//            res[i] = toupper(s[i]);
//        return res;
//    }
//
//    string Low(string s) {
//        string res = s;
//        for (int i = 0; i < s.length(); i++)
//            res[i] = tolower(s[i]);
//        return res;
//    }
//
//    int Module(int n) {
//        if (n < 0)
//            return 0 - n;
//        return n;
//    }
//
//    int CharLength(const char* s) {
//        return (unsigned)strlen(s);
//    }
//public:
//    string errorLog = "";
//    void ChangeStatus(string type, string s){
//        type = Low(type);
//        s = Low(s);
//        if (type == "errorlog") {
//            if (s == "hide")
//                status[0] = 'h';
//            else
//                status[0] = 's';
//        }else if (type == "operator-=" || type == "-=" || type == "minusing" || type == "minus") {
//            if (s == "destroy")
//                status[1] = 'd';
//            else
//                status[1] = 'e';
//        }
//    }
//
//    bool ShowStatus(string s) {
//        s = Low(s);
//        if (s == "errorlog")
//            return status[0] == 's';
//        else if (s == "minus")
//            return status[1] == 'd';
//    }
//
//    //Constructors
//    newstr() {
//        str.clear();
//    }
//    newstr(const char *strng) {
//        str.clear();
//        str.resize(CharLength(strng));
//        
//        for (int i = 0; i < CharLength(strng); i++) 
//            str[i] = strng[i];
//    }
//    newstr(string s) {
//        str.clear();
//        //copy(s.begin(), s.end(), back_inserter(str));
//        str.resize(s.length());
//
//        for (int i = 0; i < s.length(); i++)
//            str[i] = s[i];
//    }
//    newstr(vector<char> s) {
//        str.resize(s.size());
//        str = s;
//    }
//    newstr(int n) {
//        if(n > 0)
//            str.resize(n);
//    }
//
//    //Functions
//
//    int Length() {
//        return str.size();
//    }
//
//    void Erase(int index) {
//        if (index > Length() || index < 0)
//            return;//GiveError("Incorrect index"); //WARNING
//        str.erase(str.begin() + index);
//    }
//
//    void Add(int index, char value) {
//        if (index > Length() || index < 0)
//            return;//GiveError("Incorrect index"); //WARNING
//        str.insert(str.begin() + index, value);
//    }
//
//    vector<char> Organ() {
//        return str;
//    }
//
//    void Resize(int l) {
//        if (l < 0 || l >= INFINITY) {
//            GiveError("Incorrect length to resize");
//            return;
//        }
//        str.resize(l);
//    }
//
//    string ToString() {
//        string s(str.begin(), str.end());
//        return s;
//    }
//
//    void Clear() {
//        str.clear();
//    }
//
//    bool IsClear() {
//        return str.empty();
//    }
//
//    string Upper() {
//        string res = ToString();//vector<char> res = str;
//        //res.resize(Length());
//        for (int i = 0; i < Length(); i++)
//            res[i] = toupper(res[i]);
//        return res;
//    }
//
//    string Lower() {
//        string res = ToString();
//        for (int i = 0; i < Length(); i++)
//            res[i] = tolower(str[i]);
//        return res;
//    }
//
//    void MakeUpper() {
//        for (int i = 0; i < Length(); i++)
//            str[i] = toupper(str[i]);
//    }
//
//    void MakeLower() {
//        for (int i = 0; i < Length(); i++)
//            str[i] = tolower(str[i]);
//    }
//
//    bool IsLower() {
//        return *this == Lower();
//    }
//
//    bool IsUpper() {
//        return *this == Upper();
//    }
//
//    void CharsToUpper(string ex){
//        if (ex.length() > Length()) {
//            GiveError("Length of parameter in \"CharsToUpper\" function is too big(first parameter \"ex\").");
//        }
//
//        string s = "";
//        for (int i = 0; i + ex.length() <= Length(); i++) { //WARNING: Was "< Length()"
//            for (int a = i; a < i + ex.length(); a++)
//                s += str[a];
//
//            if (s == ex)
//                for (int a = i; a < i + ex.length(); a++)
//                    str[a] = toupper(str[a]);
//
//            s = "";
//        }
//    }
//
//    void CharsToLower(string ex){
//        if (ex.length() > Length()) {
//            GiveError("Length of parameter in \"CharsToUpper\" function is too big(first parameter \"ex\").");
//        }
//
//        string s = "";
//        for (int i = 0; i + ex.length() <= Length(); i++) { //WARNING: Was "< Length()"
//            for (int a = i; a < i + ex.length(); a++)
//                s += str[a];
//
//            if (s == ex)
//                for (int a = i; a < i + ex.length(); a++)
//                    str[a] = tolower(str[a]);
//
//            s = "";
//        }
//    }
//
//    void AnyCharsToUpper(string ex) {
//        if (ex.length() > Length()) {
//            GiveError("Length of parameter in \"CharsToUpper\" function is too big(first parameter \"ex\").");
//        }
//
//        string s = "";
//        for (int i = 0; i + ex.length() <= Length(); i++) { //WARNING: Was "< Length()"
//            for (int a = i; a < i + ex.length(); a++)
//                s += str[a];
//
//            if (Low(s) == Low(ex))
//                for (int a = i; a < i + ex.length(); a++)
//                    str[a] = toupper(str[a]);
//
//            s = "";
//        }
//    }
//
//    void AnyCharsToLower(string ex) {
//        if (ex.length() > Length()) {
//            GiveError("Length of parameter in \"CharsToUpper\" function is too big(first parameter \"ex\").");
//        }
//        ex = Up(ex);
//
//        string s = "";
//        for (int i = 0; i + ex.length() <= Length(); i++) { //WARNING: Was "< Length()"
//            for (int a = i; a < i + ex.length(); a++)
//                s += str[a];
//
//            if (Up(s) == ex)
//                for (int a = i; a < i + ex.length(); a++)
//                    str[a] = tolower(str[a]);
//
//            s = "";
//        }
//    }
//
//    void LittleCorrection(string example, string changeTo) {
//        if (example.length() > Length()) {
//            GiveError("Length of parameter in \"ChangeTo\" function is too big(first parameter \"example\").");
//        }
//        if (example.length() != changeTo.length()) {
//            GiveError("Length of parameters in \"ChangeTo\" function is not equal. " + to_string(example.length()) + " to " + to_string(changeTo.length()));
//        }
//
//        string s = "";
//        for (int i = 0; i + example.length() < Length(); i++) {
//            for (int a = i; a < i + example.length(); a++)
//                s += str[a];
//
//            if (s == example) 
//                for (int a = i; a < i + example.length(); a++)
//                    str[a] = changeTo[a - i];
//            
//            s = "";
//        }
//    }
//
//    void Correct(newstr example, newstr changeTo) {
//        if (example.Length() > Length()) 
//            GiveError("Length of parameter in \"Correct\" function is too big. " + to_string(example.Length()) + " to " + to_string(changeTo.Length()));
//        if (example.Upper() == Up(changeTo))
//            GiveError("Bad parameters(in this case better use LittleCorrection function)");
//        if (example == "")
//            GiveError("Empty first parameter in \"Correct\" function.");
//
//        string s = "";
//        for (int i = 0; i + example.Length() <= Length(); i++) { //WARNING: Was < Length()
//            //cout << "Iteration: " << i << ";";
//            for (int a = i; a < i + example.Length(); a++)
//                s += str[a];
//            //cout << " Found s: " << s << ";" << endl;
//            if (example/*.Upper() */ == /*Up(*/s/*)*/) {
//                //cout << "Started..." << endl;
//                for (int a = i; a < i + example.Length(); a++)
//                    Erase(i);
//                //cout << "Erasing ended: " << ToString() << endl << "Adding started: " << changeTo << ", " << i << endl;
//                for (int a = 0;/* a < example.Length() &&*/ a < changeTo.Length(); a++) {//WARNING: a < example.Length() &&
//                    //cout << "a: " << a << "; i: " << i << "; ToString(): " << ToString() << endl;
//                    Add(a + i, changeTo[a]);
//                }
//                
//                //cout << "Adding ended: " << ToString() << endl;
//                i = 0;
//            }
//            
//            s = "";
//        }
//    }
//
//    void CorrectAny(newstr example, newstr changeTo) {
//        if (example.Length() > Length())
//            GiveError("Length of parameter in \"Correct\" function is too big. " + to_string(example.Length()) + " to " + to_string(changeTo.Length()));
//        if (example.Upper() == Up(changeTo))
//            GiveError("Bad parameters(in this case better use LittleCorrection function)");
//        if (example == "")
//            GiveError("Empty first parameter in \"Correct\" function.");
//
//        string s = "";
//        for (int i = 0; i + example.Length() <= Length(); i++) { //WARNING: Was < Length()
//            //cout << "Iteration: " << i << ";";
//            for (int a = i; a < i + example.Length(); a++)
//                s += str[a];
//            //cout << " Found s: " << s << ";" << endl;
//            if (example.Upper() == Up(s)) {
//                //cout << "Started..." << endl;
//                for (int a = i; a < i + example.Length(); a++)
//                    Erase(i);
//                //cout << "Erasing ended: " << ToString() << endl << "Adding started: " << changeTo << ", " << i << endl;
//                for (int a = 0;/* a < example.Length() &&*/ a < changeTo.Length(); a++) {//WARNING: a < example.Length() &&
//                    //cout << "a: " << a << "; i: " << i << "; ToString(): " << ToString() << endl;
//                    Add(a + i, changeTo[a]);
//                }
//
//                //cout << "Adding ended: " << ToString() << endl;
//                i = 0;
//            }
//
//            s = "";
//        }
//    }
//
//    void ClearFrom(const char* s){
//        Correct(s, "");
//    }
//
//    void ClearFrom(char ch) {
//        newstr s = ch;
//        Correct(s, "");
//    }
//
//    string& LikeString() {
//        string s(str.begin(), str.end());
//        return s;
//    }
//
//    bool Contain(newstr s) {
//        for (int i = 0; i + s.length() <= Length(); i++) {
//            string s2 = "";
//            for (int a = 0; a < s.length(); a++)
//                s2 += str[a + i];
//            if (s == s2)
//                return true;
//        }
//        return false;
//    }
//
//    bool AnyContain(newstr s) {
//        for (int i = 0; i + s.length() <= Length(); i++) {
//            newstr s2 = "";
//            for (int a = 0; a < s.length(); a++)
//                s2 += str[a + i];
//
//            if (s.Upper() == Up(s2))
//                return true;
//        }
//        return false;
//    }
//
//    /*void ClearAllBefore(newstr s) {
//        if (s.Length() >= Length())
//            return;
//
//        newstr testS = "";
//        for (int i = 0; i + s.Length() <= Length(); i++) {
//            for (int a = i; a < i + s.Length(); a++)
//                testS += *this[a]; 
//            if(testS == s) Erase();
//        }
//    }
//
//    void ClearAllAfter(newstr s) {
//
//    }*/
//
//    //Translators
//
//    operator string() {
//        return ToString();
//    }
//
//    operator const char* () {
//        return ToString().c_str();
//        /*char res[];
//        for (int i = 0; i < str.size(); i++) 
//            res[i] = str[i];*/
//        //return res;
//    }
//
//    //Operators
//
//    bool operator<(newstr s) {
//        return s.Length() > Length();
//    }
//
//    bool operator>(newstr s) {
//        return s.Length() < Length();
//    }
//
//    bool operator<(string s) {
//        return s.length() > Length();
//    }
//
//    bool operator>(string s) {
//        return s.length() < Length();
//    }
//
//    //WARNING: Using class string
//    bool operator<(const char* scc) {
//        string s = scc;
//        return s.length() > Length();
//    }
//
//    //WARNING: Using class string
//    bool operator>(const char* scc) {
//        string s = scc;
//        return s.length() < Length();
//    }
//
//    void operator=(string s) {
//        str.clear();
//        //vector<char> str(s.begin(), s.end());
//        copy(s.begin(), s.end(), back_inserter(str));
//    }
//
//    //WARNING: Using string class
//    void operator=(const char* scc) {
//        string s = scc;
//        str.clear();
//        //vector<char> str(s.begin(), s.end());
//        copy(s.begin(), s.end(), back_inserter(str));
//    }
//
//    bool operator==(newstr s) {
//        return s.ToString() == ToString();
//    }
//
//    bool operator==(string s) {
//        return ToString() == s;
//    }
//
//    bool operator==(const char* s) {
//        return ToString() == s;
//    }
//
//    //WARNING: Untested
//    newstr operator+(newstr s) {
//        newstr res = *this;
//        res += s;
//        return res;
//    }
//
//    //WARNING: Untested
//    newstr operator+(const char* s) {
//        newstr res = *this;
//        res += s;
//        return res;
//    }
//
//    newstr operator+(string s) {
//        newstr res = *this;
//        res += s;
//        return res;
//    }
//
//    void operator+=(string s) {
//        copy(s.begin(), s.end(), back_inserter(str));
//    }
//
//    void operator+=(char ch) {
//        string s = "";
//        s += ch;
//        *this += s;
//        //Resize(Length() + 2);//WARNING
//        //str[Length()] = ch;
//    }
//
//    //WARNING: Giving not error but changing input parameter
//    void operator-=(int c) {
//        if (Length() == 0 || c == 0)
//            return;
//        if (c > Length())
//            c = Length();
//        //if (c >= Length())//WARNING
//        //    GiveError("Error: length if given parameter is too big.");
//        if (c < 0) {
//            c = Module(c);
//            if (c > Length())
//                c = Length();
//            
//            str.erase(str.begin(), str.begin() + c);
//            return;
//        }
//
//        int mainLength = Length();
//        bool erase = ShowStatus("minus");
//        for (int i = Length() - 1; i >= mainLength - c; i--) {
//            if (!erase)
//                str[i] = '\0';
//            else
//                str.erase(str.begin() + i);
//        }
//    }
//
//    //WARNING: Giving not error but changing input parameter
//    void operator-=(string ex) {
//        if (ex.length() >= Length()) 
//            return;//GiveError("Error: length if given parameter is too big.");
//        
//
//        string s = "";
//        bool erase = ShowStatus("minus");
//        for (int i = 0; i + ex.length() <= Length(); i++) {
//            //cout << "Count: " << i;
//            for (int a = i; a < i + ex.length(); a++)
//                s += str[a];
//            //cout << "; Got: " << s << endl;
//            if (s == ex) {
//                if (erase)
//                    for (int b = 0; b < ex.length(); b++)
//                        str.erase(str.begin() + i);
//                else
//                    for (int b = i; b < i + ex.length(); b++)
//                        str[b] = '\0';
//            }
//            s = "";
//        }
//        //start:
//        //string s = "";
//        //bool erase = ShowStatus("minus");
//        //for (int i = 0; i + ex.length() <= Length(); i++){//< Length(); i++) {
//        //    for (int a = i; a < i + ex.length(); a++)
//        //        s += str[a];
//
//        //    cout << "\"" << s << "\"" << endl;
//        //    if (s == ex) {
//        //        for (int a = i; a < i + ex.length(); a++) {/*\*/
//        //            if (!erase)
//        //                str[a] = '\0';
//        //            else 
//        //                str.erase(str.begin() + a);
//        //        }
//        //        cout << "To start..." << endl;
//        //        goto start;
//        //    }
//        //    s = "";
//        //}
//    }
//
//    //WARNING: Untested; Giving not error but changing input parameter
//    void operator-=(newstr ex) {
//        if (ex.Length() >= Length())
//            return;//GiveError("Error: length if given parameter is too big.");
//
//
//        string s = "";
//        bool erase = ShowStatus("minus");
//        for (int i = 0; i + ex.Length() <= Length(); i++) {
//            //cout << "Count: " << i;
//            for (int a = i; a < i + ex.Length(); a++)
//                s += str[a];
//            //cout << "; Got: " << s << endl;
//            if (ex == s) {
//                if (erase)
//                    for (int b = 0; b < ex.Length(); b++)
//                        str.erase(str.begin() + i);
//                else
//                    for (int b = i; b < i + ex.Length(); b++)
//                        str[b] = '\0';
//            }
//            s = "";
//        }
//    }
//
//    //WARNING: Giving not error but changing input parameter
//    void operator-=(const char* excc) {
//        string ex = excc;
//        //cout << "Started: " << ex << endl;
//        if (ex.length() >= Length())
//            return;//GiveError("Error: length if given parameter is too big.");
//        
//    start:
//        string s = "";
//        bool erase = ShowStatus("minus");
//        for (int i = 0; i + ex.length() <= Length(); i++) {
//            //cout << "Count: " << i;
//            for (int a = i; a < i + ex.length(); a++)
//                s += str[a];
//            //cout << "; Got: " << s << endl;
//            if (s == ex) {
//                if (erase)
//                    for (int b = 0; b < ex.length(); b++)
//                        str.erase(str.begin() + i);
//                else
//                    for (int b = i; b < i + ex.length(); b++)
//                        str[b] = '\0';
//            }
//            s = "";
//        }
//    }
//
//    newstr operator-(newstr s) {
//        newstr thisS = *this;
//        thisS -= s;
//        return thisS;
//    }
//
//    newstr operator-(const char* s) {
//        newstr thisS = *this;
//        thisS -= s;
//        return thisS;
//    }
//
//    newstr operator-(string s) {
//        newstr thisS = *this;
//        thisS -= s;
//        return thisS;
//    }
//
//    void operator*=(int c) {
//        //WARNING
//        if (IsClear()) {
//            Resize(c);
//            return;
//        }
//        
//        string res = ToString();
//        string was = res;
//        for (int i = 1; i < c; i++)
//            res += was;
//        *this = res;
//    }
//
//    void operator^(int c) {
//        //WARNING
//        if (IsClear()) {
//            Resize(c);
//            return;
//        }
//
//        string res = ToString();
//        string was = res;
//        for (int i = 1; i < c; i++)
//            res += res;
//        *this = res;
//    }
//
//    //Maybe good to count the number of symbols(without empty elements)
//    bool operator%(newstr s) {
//        return Length() == s.Length();
//    }
//
//    bool operator%(string s) {
//        return Length() == s.length();
//    }
//
//    bool operator%(const char *s) {
//        return Length() == strlen(s);
//    }
//
//    char& operator[](int index) {
//        if (Length() > index || 0 > index)
//            return str[index];
//        else
//            GiveError("Error: incorrect index.");//throw "Error: Incorrect index";
//    }
//
//    friend ostream& operator<<(ostream& newStream, /*const */newstr& strng) {
//        //return newStream << (const char*)strng;
//        return newStream << strng.ToString();
//    }
//
//    friend ostream& operator>>(ostream& newStream, /*const */newstr& strng) {
//        //return newStream << (const char*)strng;
//        return newStream >> strng;
//    }
//
//    //Un-nessesary
//    int length() {
//        return Length();
//    }
//    int Len() {
//        return Length();
//    }
//    int len() {
//        return Length();
//    }
//    void Empty() {
//        Clear();
//    }
//    bool IsEmpty() {
//        return IsClear();
//    }
//};

//class NUM{
//    unsigned int afterPoint;
//    __int64 value;
//
//    template<class t>
//    __int64 GetAfterPoint(t n) {
//        n -= (int)n;
//        return n;
//    }
//
//    template<class t>
//    __int64 GetBeforePoint(t n) {
//        n -= (int)n;
//        if (n != 0) {
//            while (GetAfterPoint(n) != 0)
//                n *= 10;
//        }
//        return n;
//    }
//public:
//    NUM() {
//        afterPoint = NULL;
//        value = 0;
//    }
//    NUM(int num) {
//        afterPoint = NULL;
//        value = num;
//    }
//    template<class number>
//    NUM(number num) {
//        value = GetBeforePoint(num);
//        afterPoint = GetAfterPoint(num);
//    }
//
//    //Functions
//    newstr ToNewstr() {
//        return to_string(value) + ((afterPoint != NULL) ? "," + to_string(afterPoint) : "");
//    }
//    
//    //Operators
//    operator int() {
//        if (afterPoint > 4)
//            return value + 1;
//        else
//            return value;
//    }
//    operator float() {
//        if (afterPoint != NULL) {
//            float h = afterPoint;
//            while (h > 0)
//                h /= 10;
//            return value + h;
//        }else 
//            return value;
//        
//    }
//
//    //Input/output
//    friend ostream& operator<<(ostream& newStream, /*const */NUM& number) {
//        //return newStream << (const char*)strng;
//        return newStream << /*(float)*/number;
//    }
//};

//template <typename type>
//class Array {
//private:
//    type* arr;
//public:
//    int size;
//    Array() {
//        size = 0;
//    }
//    Array(type newArr[], int s) {
//        arr = new T[s];
//        size = s;
//        for (int i = 0; i < size; i++)
//            arr[i] = newArr[i];
//    }
//    bool operator<(const char* scc) {
//        string s = scc;
//        return s.length() > Length();
//    }
//
//    //WARNING: Using class string
//    bool operator>(const char* scc) {
//        string s = scc;
//        return s.length() < Length();
//    }
//
//    void operator=(string s) {
//        str.clear();
//        //vector<char> str(s.begin(), s.end());
//        copy(s.begin(), s.end(), back_inserter(str));
//    }
//
//    //WARNING: Using string class
//    void operator=(const char* scc) {
//        string s = scc;
//        str.clear();
//        //vector<char> str(s.begin(), s.end());
//        copy(s.begin(), s.end(), back_inserter(str));
//    }
//
//    bool operator==(newstr s) {
//        return s.ToString() == ToString();
//    }
//
//    bool operator==(string s) {
//        return ToString() == s;
//    }
//
//    bool operator==(const char* s) {
//        return ToString() == s;
//    }
//
//    //WARNING: Untested
//    newstr operator+(newstr s) {
//        newstr res = *this;
//        res += s;
//        return res;
//    }
//
//    void operator+=(string s) {
//        copy(s.begin(), s.end(), back_inserter(str));
//    }
//
//    void operator-=(type e) {
//        
//        for (int i = 0; i < size - k; i++) {
//            if (arr[i] == e) 
//                arr[i] = arr[i + 1];
//            
//        }
//    }
//};

//class newstr : public string {
//private:
//    vector<char> str;
//public:
//    newstr() {
//        str.clear();
//    }
//    newstr(const char* strng) {
//        str.clear();
//        str.resize(CharLength(strng));
//
//        for (int i = 0; i < CharLength(strng); i++)
//            str[i] = strng[i];
//    }
//    newstr(string s) {
//        str.clear();
//        //copy(s.begin(), s.end(), back_inserter(str));
//        str.resize(s.length());
//
//        for (int i = 0; i < s.length(); i++)
//            str[i] = s[i];
//    }
//    newstr(vector<char> s) {
//        str.resize(s.size()); //WARNING: May be useless.
//        str = s;
//    }
//    newstr(int n) {
//        if (n > 0)
//            str.resize(n);
//    }
//
//    int Length() {
//        return str.size();
//    }
//
//    void Erase(int index) {
//        if (index > Length() || index < 0)
//            return;//GiveError("Incorrect index"); //WARNING
//        str.erase(str.begin() + index);
//    }
//
//    void Add(int index, char value) {
//        if (index > Length() || index < 0)
//            return;//GiveError("Incorrect index"); //WARNING
//        str.insert(str.begin() + index, value);
//    }
//
//    vector<char> Organ() {
//        return str;
//    }
//
//    void Resize(int l) {
//        if (l < 0 || l >= INFINITY) {
//            throw ("Incorrect length to resize");
//            return;
//        }
//        str.resize(l);
//    }
//
//    string ToString() {
//        string s(str.begin(), str.end());
//        return s;
//    }
//
//    void Clear() {
//        str.clear();
//    }
//
//    bool IsClear() {
//        return str.empty();
//    }
//
//    string Upper() {
//        string res = ToString();//vector<char> res = str;
//        //res.resize(Length());
//        for (int i = 0; i < Length(); i++)
//            res[i] = toupper(res[i]);
//        return res;
//    }
//
//    string Lower() {
//        string res = ToString();
//        for (int i = 0; i < Length(); i++)
//            res[i] = tolower(str[i]);
//        return res;
//    }
//
//    void MakeUpper() {
//        for (int i = 0; i < Length(); i++)
//            str[i] = toupper(str[i]);
//    }
//
//    void MakeLower() {
//        for (int i = 0; i < Length(); i++)
//            str[i] = tolower(str[i]);
//    }
//
//    bool IsLower() {
//        return *this == Lower();
//    }
//
//    bool IsUpper() {
//        return *this == Upper();
//    }
//
//    void CharsToUpper(string ex) {
//        if (ex.length() > Length()) {
//            throw ("Length of parameter in \"CharsToUpper\" function is too big(first parameter \"ex\").");
//        }
//
//        string s = "";
//        for (int i = 0; i + ex.length() <= Length(); i++) { //WARNING: Was "< Length()"
//            for (int a = i; a < i + ex.length(); a++)
//                s += str[a];
//
//            if (s == ex)
//                for (int a = i; a < i + ex.length(); a++)
//                    str[a] = toupper(str[a]);
//
//            s = "";
//        }
//    }
//
//    void CharsToLower(string ex) {
//        if (ex.length() > Length()) {
//            throw ("Length of parameter in \"CharsToUpper\" function is too big(first parameter \"ex\").");
//        }
//
//        string s = "";
//        for (int i = 0; i + ex.length() <= Length(); i++) { //WARNING: Was "< Length()"
//            for (int a = i; a < i + ex.length(); a++)
//                s += str[a];
//
//            if (s == ex)
//                for (int a = i; a < i + ex.length(); a++)
//                    str[a] = tolower(str[a]);
//
//            s = "";
//        }
//    }
//
//    void AnyCharsToUpper(string ex) {
//        if (ex.length() > Length()) {
//            throw ("Length of parameter in \"CharsToUpper\" function is too big(first parameter \"ex\").");
//        }
//
//        string s = "";
//        for (int i = 0; i + ex.length() <= Length(); i++) { //WARNING: Was "< Length()"
//            for (int a = i; a < i + ex.length(); a++)
//                s += str[a];
//
//            if (Low(s) == Low(ex))
//                for (int a = i; a < i + ex.length(); a++)
//                    str[a] = toupper(str[a]);
//
//            s = "";
//        }
//    }
//
//    void AnyCharsToLower(string ex) {
//        if (ex.length() > Length()) {
//            throw ("Length of parameter in \"CharsToUpper\" function is too big(first parameter \"ex\").");
//        }
//        ex = Up(ex);
//
//        string s = "";
//        for (int i = 0; i + ex.length() <= Length(); i++) { //WARNING: Was "< Length()"
//            for (int a = i; a < i + ex.length(); a++)
//                s += str[a];
//
//            if (Up(s) == ex)
//                for (int a = i; a < i + ex.length(); a++)
//                    str[a] = tolower(str[a]);
//
//            s = "";
//        }
//    }
//
//    void LittleCorrection(string example, string changeTo) {
//        if (example.length() > Length()) {
//            throw ("Length of parameter in \"ChangeTo\" function is too big(first parameter \"example\").");
//        }
//        if (example.length() != changeTo.length()) {
//            throw ("Length of parameters in \"ChangeTo\" function is not equal. " + to_string(example.length()) + " to " + to_string(changeTo.length()));
//        }
//
//        string s = "";
//        for (int i = 0; i + example.length() < Length(); i++) {
//            for (int a = i; a < i + example.length(); a++)
//                s += str[a];
//
//            if (s == example)
//                for (int a = i; a < i + example.length(); a++)
//                    str[a] = changeTo[a - i];
//
//            s = "";
//        }
//    }
//
//    void Correct(newstr example, newstr changeTo) {
//        if (example.Length() > Length())
//            throw ("Length of parameter in \"Correct\" function is too big. " + to_string(example.Length()) + " to " + to_string(changeTo.Length()));
//        if (example.Upper() == Up(changeTo))
//            throw ("Bad parameters(in this case better use LittleCorrection function)");
//        if (example == "")
//            throw ("Empty first parameter in \"Correct\" function.");
//
//        string s = "";
//        for (int i = 0; i + example.Length() <= Length(); i++) { //WARNING: Was < Length()
//            //cout << "Iteration: " << i << ";";
//            for (int a = i; a < i + example.Length(); a++)
//                s += str[a];
//            //cout << " Found s: " << s << ";" << endl;
//            if (example/*.Upper() */ == /*Up(*/s/*)*/) {
//                //cout << "Started..." << endl;
//                for (int a = i; a < i + example.Length(); a++)
//                    Erase(i);
//                //cout << "Erasing ended: " << ToString() << endl << "Adding started: " << changeTo << ", " << i << endl;
//                for (int a = 0;/* a < example.Length() &&*/ a < changeTo.Length(); a++) {//WARNING: a < example.Length() &&
//                    //cout << "a: " << a << "; i: " << i << "; ToString(): " << ToString() << endl;
//                    Add(a + i, changeTo[a]);
//                }
//
//                //cout << "Adding ended: " << ToString() << endl;
//                i = 0;
//            }
//
//            s = "";
//        }
//    }
//
//    void CorrectAny(newstr example, newstr changeTo) {
//        if (example.Length() > Length())
//            throw ("Length of parameter in \"Correct\" function is too big. " + to_string(example.Length()) + " to " + to_string(changeTo.Length()));
//        if (example.Upper() == Up(changeTo))
//            throw ("Bad parameters(in this case better use LittleCorrection function)");
//        if (example == "")
//            throw ("Empty first parameter in \"Correct\" function.");
//
//        string s = "";
//        for (int i = 0; i + example.Length() <= Length(); i++) { //WARNING: Was < Length()
//            //cout << "Iteration: " << i << ";";
//            for (int a = i; a < i + example.Length(); a++)
//                s += str[a];
//            //cout << " Found s: " << s << ";" << endl;
//            if (example.Upper() == Up(s)) {
//                //cout << "Started..." << endl;
//                for (int a = i; a < i + example.Length(); a++)
//                    Erase(i);
//                //cout << "Erasing ended: " << ToString() << endl << "Adding started: " << changeTo << ", " << i << endl;
//                for (int a = 0;/* a < example.Length() &&*/ a < changeTo.Length(); a++) {//WARNING: a < example.Length() &&
//                    //cout << "a: " << a << "; i: " << i << "; ToString(): " << ToString() << endl;
//                    Add(a + i, changeTo[a]);
//                }
//
//                //cout << "Adding ended: " << ToString() << endl;
//                i = 0;
//            }
//
//            s = "";
//        }
//    }
//
//    void ClearFrom(const char* s) {
//        Correct(s, "");
//    }
//
//    void ClearFrom(char ch) {
//        newstr s = ch;
//        Correct(s, "");
//    }
//
//    string& LikeString() {
//        string s(str.begin(), str.end());
//        return s;
//    }
//
//    bool Contain(newstr s) {
//        for (int i = 0; i + s.length() <= Length(); i++) {
//            string s2 = "";
//            for (int a = 0; a < s.length(); a++)
//                s2 += str[a + i];
//            if (s == s2)
//                return true;
//        }
//        return false;
//    }
//
//    bool AnyContain(newstr s) {
//        for (int i = 0; i + s.length() <= Length(); i++) {
//            newstr s2 = "";
//            for (int a = 0; a < s.length(); a++)
//                s2 += str[a + i];
//
//            if (s.Upper() == Up(s2))
//                return true;
//        }
//        return false;
//    }
//
//    /*void ClearAllBefore(newstr s) {
//        if (s.Length() >= Length())
//            return;
//
//        newstr testS = "";
//        for (int i = 0; i + s.Length() <= Length(); i++) {
//            for (int a = i; a < i + s.Length(); a++)
//                testS += *this[a];
//            if(testS == s) Erase();
//        }
//    }
//
//    void ClearAllAfter(newstr s) {
//
//    }*/
//
//    //Translators
//
//    operator string() {
//        return ToString();
//    }
//
//    operator const char* () {
//        return ToString().c_str();
//        /*char res[];
//        for (int i = 0; i < str.size(); i++)
//            res[i] = str[i];*/
//            //return res;
//    }
//
//    //Operators
//
//    bool operator<(newstr s) {
//        return s.Length() > Length();
//    }
//
//    bool operator>(newstr s) {
//        return s.Length() < Length();
//    }
//
//    bool operator<(string s) {
//        return s.length() > Length();
//    }
//
//    bool operator>(string s) {
//        return s.length() < Length();
//    }
//
//    //WARNING: Using class string
//    bool operator<(const char* scc) {
//        string s = scc;
//        return s.length() > Length();
//    }
//
//    //WARNING: Using class string
//    bool operator>(const char* scc) {
//        string s = scc;
//        return s.length() < Length();
//    }
//    //WARNING
//    void operator=(string s) {
//        str.clear();
//        vector<char> str(s.begin(), s.end());
//        //copy(s.begin(), s.end(), back_inserter(str));
//    }
//
//    //WARNING: Using string class
//    void operator=(const char* scc) {
//        string s = scc;
//        str.clear();
//        vector<char> str(s.begin(), s.end());
//        //copy(s.begin(), s.end(), back_inserter(str));
//    }
//
//    bool operator==(newstr s) {
//        return s.ToString() == ToString();
//    }
//
//    bool operator==(string s) {
//        return ToString() == s;
//    }
//
//    bool operator==(const char* s) {
//        return ToString() == s;
//    }
//
//    //WARNING: Untested
//    newstr operator+(newstr s) {
//        newstr res = *this;
//        res += s;
//        return res;
//    }
//
//    //WARNING: Untested
//    newstr operator+(const char* s) {
//        newstr res = *this;
//        res += s;
//        return res;
//    }
//
//    newstr operator+(string s) {
//        newstr res = *this;
//        res += s;
//        return res;
//    }
//
//    void operator+=(string s) {
//        str.resize(str.size() + s.length());
//        for (int i = 0; i < s.length(); i++)
//            str[i] = s[i];
//        //copy(s.begin(), s.end(), back_inserter(str));
//    }
//
//    void operator+=(char ch) {
//        string s = "";
//        s += ch;
//        *this += s;
//        //Resize(Length() + 2);//WARNING
//        //str[Length()] = ch;
//    }
//
//    //WARNING: Giving not error but changing input parameter
//    void operator-=(int c) {
//        if (Length() == 0 || c == 0)
//            return;
//        if (c > Length())
//            c = Length();
//        //if (c >= Length())//WARNING
//        //    GiveError("Error: length if given parameter is too big.");
//        if (c < 0) {
//            c = Module(c);
//            if (c > Length())
//                c = Length();
//
//            str.erase(str.begin(), str.begin() + c);
//            return;
//        }
//
//        int mainLength = Length();
//        bool erase = true;
//        for (int i = Length() - 1; i >= mainLength - c; i--) {
//            if (!erase)
//                str[i] = '\0';
//            else
//                str.erase(str.begin() + i);
//        }
//    }
//
//    //WARNING: Giving not error but changing input parameter
//    void operator-=(string ex) {
//        if (ex.length() >= Length())
//            return;//GiveError("Error: length if given parameter is too big.");
//
//
//        string s = "";
//        bool erase = true;
//        for (int i = 0; i + ex.length() <= Length(); i++) {
//            //cout << "Count: " << i;
//            for (int a = i; a < i + ex.length(); a++)
//                s += str[a];
//            //cout << "; Got: " << s << endl;
//            if (s == ex) {
//                if (erase)
//                    for (int b = 0; b < ex.length(); b++)
//                        str.erase(str.begin() + i);
//                else
//                    for (int b = i; b < i + ex.length(); b++)
//                        str[b] = '\0';
//            }
//            s = "";
//        }
//        //start:
//        //string s = "";
//        //bool erase = true;
//        //for (int i = 0; i + ex.length() <= Length(); i++){//< Length(); i++) {
//        //    for (int a = i; a < i + ex.length(); a++)
//        //        s += str[a];
//
//        //    cout << "\"" << s << "\"" << endl;
//        //    if (s == ex) {
//        //        for (int a = i; a < i + ex.length(); a++) {/*\*/
//        //            if (!erase)
//        //                str[a] = '\0';
//        //            else 
//        //                str.erase(str.begin() + a);
//        //        }
//        //        cout << "To start..." << endl;
//        //        goto start;
//        //    }
//        //    s = "";
//        //}
//    }
//
//    //WARNING: Untested; Giving not error but changing input parameter
//    void operator-=(newstr ex) {
//        if (ex.Length() >= Length())
//            return;//GiveError("Error: length if given parameter is too big.");
//
//
//        string s = "";
//        bool erase = true;
//        for (int i = 0; i + ex.Length() <= Length(); i++) {
//            //cout << "Count: " << i;
//            for (int a = i; a < i + ex.Length(); a++)
//                s += str[a];
//            //cout << "; Got: " << s << endl;
//            if (ex == s) {
//                if (erase)
//                    for (int b = 0; b < ex.Length(); b++)
//                        str.erase(str.begin() + i);
//                else
//                    for (int b = i; b < i + ex.Length(); b++)
//                        str[b] = '\0';
//            }
//            s = "";
//        }
//    }
//
//    //WARNING: Giving not error but changing input parameter
//    void operator-=(const char* excc) {
//        string ex = excc;
//        //cout << "Started: " << ex << endl;
//        if (ex.length() >= Length())
//            return;//GiveError("Error: length if given parameter is too big.");
//
//    start:
//        string s = "";
//        bool erase = true;
//        for (int i = 0; i + ex.length() <= Length(); i++) {
//            //cout << "Count: " << i;
//            for (int a = i; a < i + ex.length(); a++)
//                s += str[a];
//            //cout << "; Got: " << s << endl;
//            if (s == ex) {
//                if (erase)
//                    for (int b = 0; b < ex.length(); b++)
//                        str.erase(str.begin() + i);
//                else
//                    for (int b = i; b < i + ex.length(); b++)
//                        str[b] = '\0';
//            }
//            s = "";
//        }
//    }
//
//    newstr operator-(newstr s) {
//        newstr thisS = *this;
//        thisS -= s;
//        return thisS;
//    }
//
//    newstr operator-(const char* s) {
//        newstr thisS = *this;
//        thisS -= s;
//        return thisS;
//    }
//
//    newstr operator-(string s) {
//        newstr thisS = *this;
//        thisS -= s;
//        return thisS;
//    }
//
//    void operator*=(int c) {
//        //WARNING
//        if (IsClear()) {
//            Resize(c);
//            return;
//        }
//
//        string res = ToString();
//        string was = res;
//        for (int i = 1; i < c; i++)
//            res += was;
//        *this = res;
//    }
//
//    void operator^(int c) {
//        //WARNING
//        if (IsClear()) {
//            Resize(c);
//            return;
//        }
//
//        string res = ToString();
//        string was = res;
//        for (int i = 1; i < c; i++)
//            res += res;
//        *this = res;
//    }
//
//    //Maybe good to count the number of symbols(without empty elements)
//    bool operator%(newstr s) {
//        return Length() == s.Length();
//    }
//
//    bool operator%(string s) {
//        return Length() == s.length();
//    }
//
//    bool operator%(const char* s) {
//        return Length() == strlen(s);
//    }
//
//    char& operator[](int index) {
//        if (Length() > index || 0 > index)
//            return str[index];
//        else
//            throw ("Error: incorrect index."); //throw "Error: Incorrect index";
//    }
//
//    friend ostream& operator<<(ostream& newStream, /*const */newstr& strng) {
//        //return newStream << (const char*)strng;
//        return newStream << strng.ToString();
//    }
//
//    friend ostream& operator>>(ostream& newStream, /*const */newstr& strng) {
//        //return newStream << (const char*)strng;
//        return newStream >> strng;
//    }
//};

//class line:public string{};