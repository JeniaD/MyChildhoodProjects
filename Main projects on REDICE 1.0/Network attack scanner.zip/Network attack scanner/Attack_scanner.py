import sys
import os
from basic import *

Initiate()

print("Attack scanner,", VERSION + "v.\n")
print("Local IP found:", PublicIP)
print("Hostname found:", hostname)
print("MAC addr found:", MAC, "(" + str("".join(c + ":" if i % 2 else c for i, c in enumerate(hex(MAC)[2:].zfill(12)))[:-1]) + ")")
print("Nmaps v. found:", scanner.nmap_version())

while True:
    try:
        target = input("> ")

        if target.upper() == "SHELL" or target.upper() == "CMD" or target.upper() == "BASH":
            CmdExecute()

        if ';' in target:
            target = target.split('; ')
            #target = target.split(';')
            for t in target:
                scanner.scan(t)
                print("Scan for", t, "done.")
                ShowResults(scanner, t)
        elif target.upper() == "WATCH":
            target = PublicIP.split('.')
            target[len(target)-1] = '0'
            scanner.scan(hosts=DEFAULTLOCALIPRANGE, arguments='-sn')
                #hosts_list = [(x, scanner[x]['status']['state']) for x in scanner.all_hosts()]

            for IP in scanner.all_hosts(): #WARNING: If hosts are adding to the scanner when scanning, needs to be initialized every iteration.
                InShort(scanner, IP)
            if scanner.all_hosts() == []:
                print("No results. Scanning for:", DEFAULTLOCALIPRANGE)
                print("It can be changed by command \"set 192.168.?.0-255\", where ? - needs to choose.")
        elif target[0].upper() + target[1].upper() + target[2].upper() == "SET":
            target.split(' ')
            DEFAULTLOCALIPRANGE = target[1]
        elif FirstLetters(target, 3).upper() == "RUN": #target.upper().count("LOAD"):
            target = target.split(' ')
            target.pop(0)
            ''.join(target)
            LoadExtension(target)
        elif FirstLetters(target, 4).upper() == "LOAD":
            target = target.split(' ')
            target.pop(0)
            ''.join(target)
            DownoadExtension(target)
        elif target.upper() == "HELP":
            Help()
        elif target.upper() == "LOG":
            print(DEBUGLOG)
        else:
            print("Scanning...")
            scanner.scan(target) #, "0-443")
            print("Scan for", target, "done.")
            for IP in scanner.all_hosts(): #WARNING: If hosts are adding to the scanner when scanning, needs to be initialized every iteration.
                ShowResults(scanner, IP)
    except Exception as e:
        print("\nError:", e)
    
print("End.")

'''
import sys
import os

try:
    import nmap
except:
    print("Module nmap import error. Needs to install it on Python(pip install python-nmap).")

try:
    scanner = nmap.PortScanner()
except nmap.PortScannerError:
    print('Nmap error', sys.exc_info()[0])
    sys.exit(0)
except:
    print("Unexpected error:", sys.exc_info()[0])
    sys.exit(0)

from basic import *
'''