import os
from uuid import getnode as get_mac
import socket

try:
    import nmap
except:
    print("Module nmap import error. Needs to install it on Python(pip install python-nmap).")

try:
    scanner = nmap.PortScanner()
except nmap.PortScannerError:
    print('Nmap error', sys.exc_info()[0])
    sys.exit(0)
except:
    print("Unexpected error:", sys.exc_info()[0])
    sys.exit(0)

VERSION = "1"
DEFAULTLOCALIPRANGE = "192.168.2.0-255"
MAC = get_mac()
hostname = socket.gethostname()
PublicIP = socket.gethostbyname(hostname)

MODULEFILENAME = "start.py"
DEBUGLOG = ""

def WriteClearly(s, target):
    for arr in s[target]: #s:
        try:
            if arr == "hostnames":
                print("Hostnames:")
                print(" Name:", s[target][arr][0]["name"])
                print(" Type:", s[target][arr][0]["type"])
            elif arr == "addresses":
                print("Addresses:")
                print(" IPv4:", s[target][arr]["ipv4"])
                print(" MAC:", s[target][arr]["mac"])
            elif arr == "status":
                print("Status:")
                if s[target][arr]["state"] != None:
                    print(" State:", s[target][arr]["state"])
                if s[target][arr]["reason"] != None:
                    print(" Reason:", s[target][arr]["reason"])
                if s[target][arr]["product"] != None:
                    print(" Product:", s[target][arr]["product"])
                if s[target][arr]["version"] != None:
                    print(" Version:", s[target][arr]["version"])
                if s[target][arr]["extrainfo"] != None:
                    print(" Extra info:", s[target][arr]["extrainfo"])
                if s[target][arr]["conf"] != None:
                    print(" \"Conf\":", s[target][arr]["conf"])
                if s[target][arr]["cpe"] != None:
                    print(" \"Cpe\":", s[target][arr]["cpe"])
            elif arr == "tcp":
                print("TCP's:")
                for num in s[target][arr]:#["tcp"]:
                    print("", num)
                    for ex in s[target][arr][num]:
                        if len(s[target][arr][num][ex]) > 1: #WARNING
                            print("  " + str(ex) + ":", s[target][arr][num][ex])
                    #if s[target][arr]["tcp"][num]["state"] == "open":
                        #print("", num, s[target][arr]["tcp"][num])
        except Exception as e:
            ... #print(e)

    '''
    s[target]:
        hostnames
            name
            type
        addresses
            ipv4
            mac
        vendor
        status
            state
            reason
            product
            version
            extrainfo
            conf
            cpe
        tcp
            *number*
                state
                reason
                name
                product
                version
                extrainfo
                conf
                cpe

    '''

def InShort(s, target):
    try:
        print("Name:", s[target]["hostnames"][0]["name"])
        #print(" Type:", s[target]["hostnames"][0]["type"])
        print(" IPv4:", s[target]["addresses"]["ipv4"])
        print(" MAC:", s[target]["addresses"]["mac"])
        #print(" State:", scanner[target].state())
        print(" Connection tech guess:", s[target]["vendor"][s[target]["addresses"]["mac"]])
    except Exception as e:
        ... #print("Error:", e)
    print()

def LoadExtension(file):
    try:
        exec(file)
    except Exception as e:
        print("Error in loading extension:", e)

def DownoadExtension(url):
    try:
        #https://raw.githubusercontent.com/Name/ProjectName/main/fileName
        import requests
        from os import getcwd

        directory = getcwd()
        filename = directory + (''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(15))) + ".py"
        r = requests.get(url)

        f = open(filename, 'w')
        f.write(r.content)
        exec(file)
    except Exception as e:
        print("Error in loading extension:", e)

def PythonExecute():
    try:
        while True:
            exec(input("Python >>> "))
    except:
        ...

def CmdExecute():
    try:
        while True:
            os.system(input("Cmd >> "))
    except:
        ...

def ShowResults(scanner, target):
    try:
        print("Scan results for:", target)
        print("Detected status:", scanner[target].state())
        #print("Detected information:", scanner.scaninfo())
        print("Detected hosts:", scanner.all_hosts())

        WriteClearly(scanner, target) #print("Found info:", scanner[target])
    except KeyError:
        print("Key error.")
    except Exception as e:
        print("Error:", e)

def FirstLetters(s, number):
    res = ""
    try:
        a = 0
        while a < number:
            res += s[a]
            a += 1
    except:
        ...
    return res

def Help():
    print("Scan target: \n > IP(example: 192.168.0.1)\nYou can also scan multiple IPs: \n > 192.168.0.0; 192.168.0.1\n")
    print("Scan for devices in network: \n > watch\n It may show not all of the devices, so better to do this multiple times.\n")
    print("Add extension: \"load https://raw.github.com/Name/ProjectName/main/fileName\"\n")
    print("Execute .py file: \"run extension.py\"\n")

    print("\nTo show debug log: \"log\"")
    print("To make extension, just put folder in the this program directory, with \"" + MODULEFILENAME + "\" file as extension.")

def Initiate():
    dirs = []
    #print(os.listdir())
    for root, dirnames, filenames in os.walk('.'):
        dirs += dirnames
    dirs.remove("__pycache__")

    for component in dirs:
        os.walk(component)
        if MODULEFILENAME in os.listdir():
            exec(component + MODULEFILENAME)
        else:
            DEBUGLOG += component + " not imported.\n"

'''
import getmac
from getmac import get_mac_address
ETHMAC = get_mac_address(interface="eth0")
WINMAC = get_mac_address(interface="Ethernet 3")
IPMAC = get_mac_address(ip="192.168.0.1")
IP6MAC = get_mac_address(ip6="::1")
HOSTMAC = get_mac_address(hostname="localhost")
UPDATEDMAC = get_mac_address(ip="10.0.0.1", network_request=True)
print("Other:")
print(" Eth0:", ETHMAC)
print(" Ethernet 3:", WINMAC)
print(" IP MAC:", IPMAC)
print(" IP 6 MAC:", IP6MAC)
print(" Host MAC:", HOSTMAC)
print(" Update MAC:", UPDATEDMAC)
'''