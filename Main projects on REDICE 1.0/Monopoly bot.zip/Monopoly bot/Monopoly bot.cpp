﻿#include <iostream>
#include <string>
#include <cstdlib>
#include <windows.h> //#include <unistd.h>

using namespace std;

int MakeGoodSum(int num) {
    while (num % 50 != 0 && num != 0)
        num--;
    return num;
}

int money = 5000, turn = 0, creditGetted = 0, deposit = 0, companyesOwned = 0, maxCredit = 5000;

int Procent(int max, int curr) {
    return int((curr * 100) / max);
}

class Slot {
public:
    bool isCompany, isBoughtByAI, isBoughtByEnemy, isProfit, isInspection;
    string name;
    int cost, profit, profitBy2, profitBy3, group;

    void MakeCompany(string n, int c, int prof, int g) {
        profit = prof;
        profitBy2 = prof * 2;
        profitBy3 = profitBy2 * 2;

        cost = c;

        isCompany = true;
        isBoughtByAI = false;
        isBoughtByEnemy = false;

        name = n;
        group = g;
    }
    void MakeProfit(int sum) {
        isCompany = false;
        isBoughtByAI = false;
        isBoughtByEnemy = false;
        isProfit = true;
        isInspection = false;
        profit = sum;
    }
    void MakeInspection(int sum) {
        isCompany = false;
        isBoughtByAI = false;
        isBoughtByEnemy = false;
        isProfit = false;
        isInspection = true;
        cost = sum;
    }
};

Slot slots[36];

int CompanyesOwned(int g) {
    int c = 0;
    for (int i = 0; i < 36; i++)
        if (slots[i].group == g && slots[i].isBoughtByAI)
            c++;

    return c;
}

bool PossibleToBuy(Slot slot) {
    if (!slot.isBoughtByEnemy && !slot.isInspection && !slot.isProfit && slot.isCompany
        && !slot.isBoughtByAI)//<<
        return true;
    else
        return false;
}
/*
bool BetterBuy(Slot slot){
  if(PossibleToBuy(slot) && money >= 50){
    if (26 > Procent(money, slot.cost))
      return true;
    else if(61 > Procent(money, slot.cost) && 2 == CompanyesOwned(slot.group))
      return true;
    else if(41 > Procent(money, slot.cost) && 1 == CompanyesOwned(slot.group))
      return true;
  }
  return false;
}*/
int if0own = 26, if1own = 41, if2own = 61;
bool BetterBuy(Slot slot) {
    if (PossibleToBuy(slot) && money >= 50) {
        if (if0own > Procent(money, slot.cost))
            return true;
        else if (if1own > Procent(money, slot.cost) && 1 == CompanyesOwned(slot.group))
            return true;
        else if (if2own > Procent(money, slot.cost) && 2 == CompanyesOwned(slot.group))
            return true;
    }
    return false;
}

int ProcentByProcent(int max, int procent) {
    return int((max / 100) * procent);
}

void Buy(Slot& slot) {
    if (!PossibleToBuy(slot)) {
        cout << "Error: not possible to buy enemy company; Company aren't bought." << endl;
        return;
    }
    money -= slot.cost;
    slot.isCompany = true;
    slot.isBoughtByAI = true;
    slot.isBoughtByEnemy = false;
    slot.isProfit = false;
    slot.isInspection = false;
}

void MakeAINeurons(int a, int b, int c) {
    if0own = a + 1;
    if1own = b + 1;
    if2own = c + 1;
}

int AllCompanyes() {
    int c = 0;
    for (int i = 0; i < 36; i++)
        if (slots[i].isBoughtByAI)
            c++;

    return c;
}

void CheckPlus(int t) {
    if (t == 1)
        ::money += 1500;
    else if (t == 10)
        ::money += 2000;
    else if (t == 24)
        ::money += 5000;
    else if (t == 6 || t == 18 || t == 23)
        ::money -= 500 * AllCompanyes();
}

int main() {
    //Slot slots[36];
    int makeChoise = 0;

    slots[2].MakeCompany("Adidas", 500, 150, 1);
    slots[3].MakeCompany("Nike", 700, 200, 1);
    slots[4].MakeCompany("Versace", 900, 250, 1);


    slots[7].MakeCompany("Porsche", 1000, 250, 2);
    slots[8].MakeCompany("Volkswagen", 1200, 250, 2);
    slots[9].MakeCompany("Audi", 1500, 300, 2);


    slots[12].MakeCompany("Nokia", 1800, 350, 3);
    slots[13].MakeCompany("Apple", 2000, 350, 3);
    slots[14].MakeCompany("Samsung", 2300, 400, 3);
    slots[15].MakeCompany("Avon", 2500, 400, 4);
    slots[16].MakeCompany("Nivea", 2800, 450, 4);
    slots[17].MakeCompany("Wella", 3100, 450, 4);


    slots[20].MakeCompany("Subway", 3300, 500, 5);
    slots[21].MakeCompany("KFC", 3500, 500, 5);
    slots[22].MakeCompany("McDonald's", 3700, 550, 5);


    slots[25].MakeCompany("Football Real", 4000, 550, 6);
    slots[26].MakeCompany("Football Milan", 4200, 600, 6);
    slots[27].MakeCompany("Football Chelsy", 4300, 650, 6);


    slots[30].MakeCompany("THY", 4500, 700, 7);
    slots[31].MakeCompany("British Airwaves", 4700, 750, 7);
    slots[32].MakeCompany("Continental Airlines", 4800, 750, 7);
    slots[33].MakeCompany("Shell", 5000, 800, 8);
    slots[34].MakeCompany("BP", 5500, 850, 8);
    slots[35].MakeCompany("ExonMobil", 6000, 850, 8);

    system("cls");

choose:
    //Default: if0own = 26, if1own = 41, if2own = 61;
    cout << "What type of playng?" << endl;
    cout << " 1) Risky(50%, 65%, 80%)" << endl;
    cout << " 2) Default(25%, 40%, 60%)" << endl;
    cout << " 3) Slow(20%, 35%, 45%)" << endl;

    cout << "Number of chosen: ";
    int ch = 0;
    cin >> ch;

    if (ch == 1)
        MakeAINeurons(50, 65, 80);
    else if (ch == 2)
        MakeAINeurons(25, 40, 60);
    else if (ch == 3)
        MakeAINeurons(20, 35, 45);
    else {
        system("cls");
        goto choose;
    }

    cout << "What is money at start? ";
    cin >> money;

start:
    while (money >= 0) {
        //Test:
        CheckPlus(turn);//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

        if (creditGetted > 0) {
            //MAKE ANOTHER SOMETHING HERE
            if (money > 1000) {
                cout << endl << "Making credit down...(" << money << " - " <<
                    MakeGoodSum(ProcentByProcent(money, 10)) << " money)" << endl;
                int a = MakeGoodSum(ProcentByProcent(money, 10));//HERE NEEDS TO CHANGE CREDIT GIVING
                money -= a;
                creditGetted -= a;
            }
        }

        cout << "Statistic: " << endl;
        cout << " Money: " << money << endl;
        cout << " Credit getted: " << creditGetted << endl;
        cout << " Current turn: " << turn << endl;
        cout << " Companyes owned: " << companyesOwned << endl << endl;
        makeChoise = 0;
        cout << "AI turn: ";
        cin >> makeChoise;
        turn += makeChoise;
        if (turn > 36)
            turn -= 36;

        cout << "What is minus?: ";
        bp1:
        int m = 0;
        cin >> m;
        money -= m;

        //cout << "Procent(money, company cost) = " << Procent(money, slots[turn].cost) << endl;
        if (BetterBuy(slots[turn])) {
            cout << "Buying slot named " << slots[turn].name << ". \n";
            cout << "Is it possible to buy? 1/0 "; //<< endl;
            int a;
            cin >> a;
            if (a) {
                Buy(slots[turn]);
                cout << "Bought!" << endl;
                companyesOwned++;//<<<<<<<<<<<<<<<<<<<<<<<<
            }
            else {
                slots[turn].isBoughtByEnemy = true;
                cout << "Ok.." << endl;
            }
        }
        cout << endl << "End of turn." << endl;
        Sleep(5000);
        system("cls"); //<<<<<<<<<<<<<<<<<<<
    }
    //EXTRA
    if (creditGetted < 0) {
        cout << endl;
        cout << "Getting all credit(given by A.I.) back!" << endl;
        money -= creditGetted;
        creditGetted = 0;
        cout << endl;
        if (money >= 0)
            goto start;
    }
    else if (creditGetted < maxCredit) {
        cout << "Get credit!!!\n";
        cout << "Credit getted: " << creditGetted;
        cout << "Money: " << money;
        money += maxCredit - creditGetted;
        creditGetted = maxCredit;//<<BETTER CHANGE HERE!
        cout << endl;
        if (money >= 0)
            goto start;
    }
    else
        cout << endl << "The end of game.";
}