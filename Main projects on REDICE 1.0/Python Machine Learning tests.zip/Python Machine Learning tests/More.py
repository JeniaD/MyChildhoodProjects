from numpy import exp, array, random, dot
import numpy as np
import random
'''
def Sigmoid(x):
    return 1 / (1 + exp(-x))

def SigmoidDerivative(x):
    return x * (1 - x)

def NormalIndex(array, index):
    try:
        a = array[index]
        return True
    except:
        return False

#WARNING: Unsafe class and bias may not work.
class Neuron():
    def __init__(self, weightsNumber, newBias=0):
        self.weights = [None] * weightsNumber #[random.random()] * weightsNumber #{}[321] #weights[weightsNumber] = {}
        self.inputs = weightsNumber
        
        self.bias = newBias
        #WARNING: Was commented:
        a = 0
        while a < weightsNumber:
            self.weights[a] = random.random()
            a += 1
        #WARNING end.

    def RandomizeWeights(self):
        a = 0
        while a < self.inputs:
            self.weights[a] = random.random()
            a += 1

    def Predict(self, input, inputNeuronIndex):
        output = Sigmoid(input * self.weights[inputNeuronIndex]) #WARNING
        return output
        
        try:
            output = [None] * self.inputs #output[inputs] = {}
            for i in range(self.inputs):
                output[i] = Sigmoid(input[i] * self.weights[i]) #WARNING
            return output
        except Exception as e:
            raise RuntimeError(e)

    def Feed(self, inputs):
        #print(" Neuron weights:", self.weights)
        output = 0
        try:
            a = 0
            #WARNING: Test function.
            while NormalIndex(inputs, a):
                try:
                    output += inputs[a]*self.weights[a]
                except Exception as e:
                    print(e, "inputs:", inputs[a])#print("Exception happend: it may be because of inputs to neuron is too much or not enough!", e, a)
                    pass
                a += 1
        except Exception as e:
            print("inputs:", inputs, "weights:", self.weights, e)
            #inputs variable is maybe not an array but an number:
            output = inputs * self.weights[0] #self.weights
        print("Weights:", self.weights)
        print("Before sigmoid:", output)
        output = Sigmoid(output + self.bias)
        print("After sigmoid:", output)
        print("  Input:", inputs, "\n  Output:", output)
        return output

    def __str__(self):
        return "Neuron[" + str(self.weights) + "]"

    def __repr__(self):
        return "N[" + str(self.weights).replace('[', '').replace(']', '') + "]" #return super().__repr__()
'''
'''
class Network():
    def __init__(self, neurons = [1, 1]):
        self.neurons = []
        for num in neurons:
            a = 0
            while a != num:
                self.neurons[num][a] = Neuron()
                a -= 1
'''

import More
from More import *
#n = Neuron(3)
#from More import Network
net = Network(3)
net.AddLayer(2)
net.Prepaire()
res = net.Predict([1.32, 5.342, 0.1])
print(res)

while True:
    try:
        exec(input("> "))
    except Exception as e:
        print(e)

exit()
def plot_image(i, predictions_array, true_label, img):
  predictions_array, true_label, img = predictions_array[i], true_label[i], img[i]
  plt.grid(False)
  plt.xticks([])
  plt.yticks([])

  plt.imshow(img, cmap=plt.cm.binary)

  predicted_label = np.argmax(predictions_array)
  if predicted_label == true_label:
    color = 'blue'
  else:
    color = 'red'

  plt.xlabel("{} {:2.0f}% ({})".format(class_names[predicted_label],
                                100*np.max(predictions_array),
                                class_names[true_label]),
                                color=color)

def PlotValueArray(i, predictions_array, true_label):
  predictions_array, true_label = predictions_array[i], true_label[i]
  plt.grid(False)
  plt.xticks([])
  plt.yticks([])
  thisplot = plt.bar(range(10), predictions_array, color="#777777")
  plt.ylim([0, 1])
  predicted_label = np.argmax(predictions_array)

  thisplot[predicted_label].set_color('red')
  thisplot[true_label].set_color('blue')

try:
    import tensorflow as tf
    from tensorflow import keras

    import numpy as np
    import matplotlib.pyplot as plt
except Exception as e:
    print("Error:", e)
else:
    print("Libraryes loading done.")
    print(tf.__version__)

print("Loading dataset...")

fashion_mnist = keras.datasets.fashion_mnist
(trainImages, trainLabels), (testImages, testLabels) = fashion_mnist.load_data()

print("Loading dataset done.")

class_names = ['T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat', 'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot']

''' 
#To show image:
plt.figure()
plt.imshow(trainImages[0])
plt.colorbar()
plt.grid(False)
plt.show()
'''

trainImages = trainImages / 255.0
testImages = testImages / 255.0

plt.figure(figsize=(10,10))
for i in range(25):
    plt.subplot(5,5,i+1)
    plt.xticks([])
    plt.yticks([])
    plt.grid(False)
    plt.imshow(trainImages[i], cmap=plt.cm.binary)
    plt.xlabel(class_names[trainLabels[i]])
plt.show()

#Creating model
model = keras.Sequential([
    keras.layers.Flatten(input_shape=(28, 28)),
    keras.layers.Dense(128, activation='relu'),
    keras.layers.Dense(10, activation='softmax')
])

#Teaching model
model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
model.fit(trainImages, trainLabels, epochs = 10)

#Accuracy test
testLoss, testAcc = model.evaluate(testImages,  testLabels, verbose = 2)
print('\nAccuracy:', testAcc)

#Predictions
predictions = model.predict(testImages)
'''
num_rows = 5
num_cols = 3
num_images = num_rows*num_cols
plt.figure(figsize=(2*2*num_cols, 2*num_rows))
for i in range(num_images):
  plt.subplot(num_rows, 2*num_cols, 2*i+1)
  plot_image(i, predictions, testLabels, testImages)
  plt.subplot(num_rows, 2*num_cols, 2*i+2)
  PlotValueArray(i, predictions, testLabels)
plt.show()
'''
img = (np.expand_dims(testImages[0], 0))
predictionsSingle = model.predict(img)
print("Predictions: ", predictionsSingle)
PlotValueArray(0, predictionsSingle, testLabels)
_ = plt.xticks(range(10), class_names, rotation=45)
np.argmax(predictionsSingle[0])



''' NEW LINES '''
from numpy import exp, array, random, dot
import numpy as np
import random

import matplotlib.pyplot as plt
'''
class colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
'''
def Check(correctAns, res):
    if correctAns == int(round(res[0])):
        print("Correct.")
    else:
        print("Wrong.")

    if correctAns == 1:
        print("Good procent ~ ", round(res[0]*100), "%", sep = '')
    else:
        print("Good procent ~ ", round(50 - (100 - (res[0]*100))), "%", sep = '')

def Module(x):
    if x >= 0:
        return x
    else:
        return x * -1

class NeuralNetwork():
    def __init__(self):
        random.seed(1)

        # We model a single neuron, with 3 input connections and 1 output connection.
        # We assign random weights to a 3 x 1 matrix, with values in the range -1 to 1
        # and mean 0.
        self.synaptic_weights = 2 * 1#random(3, 1) - 1 #random.random((3, 1)) - 1

    # The Sigmoid function, which describes an S shaped curve.
    # We pass the weighted sum of the inputs through this function to
    # normalise them between 0 and 1.
    def __sigmoid(self, x):
        return 1 / (1 + exp(-x))

    # The derivative of the Sigmoid function.
    # This is the gradient of the Sigmoid curve.
    # It indicates how confident we are about the existing weight.
    def __sigmoid_derivative(self, x):
        return x * (1 - x)

    # We train the neural network through a process of trial and error.
    # Adjusting the synaptic weights each time.
    def train(self, training_set_inputs, training_set_outputs, number_of_training_iterations):
        for iteration in range(number_of_training_iterations):
            #xrange(number_of_training_iterations):
            # Pass the training set through our neural network (a single neuron).
            output = self.think(training_set_inputs)

            # Calculate the error (The difference between the desired output
            # and the predicted output).
            error = training_set_outputs - output

            # Multiply the error by the input and again by the gradient of the Sigmoid curve.
            # This means less confident weights are adjusted more.
            # This means inputs, which are zero, do not cause changes to the weights.
            adjustment = dot(training_set_inputs.T, error * self.__sigmoid_derivative(output))

            # Adjust the weights.
            self.synaptic_weights += adjustment

    # The neural network thinks.
    def think(self, inputs):
        # Pass inputs through our neural network (our single neuron).
        return self.__sigmoid(dot(inputs, self.synaptic_weights))

#import matplotlib.pyplot as plt
#import matplotlib as mpl

import random as rand
class RegressionN():
    '''
    def func(self, x, A, c, d):
        return A*np.exp(c*x) + d
    def NewGuess(self, x, y):
        x_samp = x
        y_samp = y
        plt.plot(x_samp, y_samp, "ko", label="Data")

        x_lin = np.linspace(0, x_samp.max(), 50) # a number line, 50 evenly spaced digits between 0 and max

        # Trials
        A, c, d = -1, -1e-2, 1
        y_trial1 = self.func(x_lin,  A,     c, d)
        y_trial2 = self.func(x_lin, -1, -1e-3, 1)
        y_trial3 = self.func(x_lin, -1, -3e-3, 1)

        plt.plot(x_lin, y_trial1, "--", label="Trial 1")
        plt.plot(x_lin, y_trial2, "--", label="Trial 2")
        plt.plot(x_lin, y_trial3, "--", label="Trial 3")
        #plt.legend()

        # REGRESSION ------------------------------------------------------------------
        p0 = [-1, -3e-3, 1]                                        # guessed params
        w, _ = opt.curve_fit(self.func, x_samp, y_samp, p0=p0)     
        print("Estimated Parameters", w)  

        # Model
        y_model = self.func(x_lin, *w)

        # PLOT ------------------------------------------------------------------------
        # Visualize data and fitted curves
        plt.plot(x_samp, y_samp, "ko", label="Data")
        plt.plot(x_lin, y_model, "k--", label="Fit")
        plt.title("Least squares regression")
        plt.legend(loc="upper left")

    def mnkGP(self, x, y): # ������� ������� ����� ������������� � ��������
        n=len(x) # ���������� ��������� � �������
        s=sum(y) # ����� �������� y
        s1=sum([1/x[i] for i in  range(0,n)]) #  ����� 1/x
        s2=sum([(1/x[i])**2 for i in  range(0,n)]) #  ����� (1/x)**2
        s3=sum([y[i]/x[i]  for i in range(0,n)])  # ����� y/x     
        a= round((s*s2-s1*s3)/(n*s2-s1**2),3) # ���������� � � ����� �������� �������
        b=round((n*s3-s1*s)/(n*s2-s1**2),3)# ���������� b � ����� �������� �������
        s4=[a+b/x[i] for i in range(0,n)] # ������ �������� ��������������� �������
        so=round(sum([abs(y[i] -s4[i]) for i in range(0,n)])/(n*sum(y))*100,3)   # ������� ������ �������������
        plt.title('������������� ���������� Y='+str(a)+'+'+str(b)+'/x\n ������� ������--'+str(so)+'%',size=14)
        plt.xlabel('���������� X', size=14)
        plt.ylabel('���������� Y', size=14)
        plt.plot(x, y, color='r', linestyle=' ', marker='o', label='Data(x,y)')
        plt.plot(x, s4, color='g', linewidth=2, label='Data(x,f(x)=a+b/x')
        plt.legend(loc='best')
        plt.grid(True)
        plt.show()

    '''
    class Res():
        def __init__(self, k, b):#, e):
            self.k = k
            self.b = b
            #self.e = e
            self.error = 0
        def Predict(self, x):
            return self.k * x + self.b
        def __repr__(self):
            return "f(x) = " + str(self.k) + "x + " + str(self.b) + ";"
        def Test(self, inputs, outputs):
            b = 0
            while b < len(inputs) - 1:#WARNING: " - 1"
                #WARNING: Calculate max error(may be better average):
                self.error = (self.error + (self.Predict(inputs[b]) - outputs[b])) / 2
                b += 1
    def Linear(self, inputs, outputs, trainings):
        a = 0
        randomExamples = 100
        results = [None] * randomExamples
        maxRandRange = 100 *10
        
        print("Initializing random answers and calculating its errors...")
        while a < randomExamples:
            results[a] = self.Res(random.uniform(0 - maxRandRange, maxRandRange), random.uniform(0 - maxRandRange, maxRandRange))
            #print("Result", a, "\b, k =", results[a].k, "\b; b =", results[a].b)

            #WARNING: Calculating error formula here is: prediction - output sample;
            #WARNING: More safe but slow option. Another option to make random inputs-outputs predictions \
            #and make average of error. Or 1 random input-output...
            b = 0
            while b < len(inputs) - 1:#WARNING: " - 1"
                #WARNING: Calculate max error(may be better average):
                results[a].error = (results[a].error + (results[a].Predict(inputs[b]) - outputs[b])) / 2
                b += 1
            a += 1
        
        #Sorting:
        print("Sorting results...")
        a = 1
        while a < len(results):
            #print(a)
            if Module(results[a].error) < Module(results[a - 1].error):
                #print(results[a].error, "with", results[a - 1].error)
                h = results[a - 1]
                results[a - 1] = results[a]
                results[a] = h
                #WARNING:
                if a == 1:
                    a = 0
                else:
                    a -= 2
            a += 1
        #print(results)
        print("Saving results...")
        self.bestRes = results[0]

        #Better improve this answer(function):
        print("Improving answer...")
        testRes = self.bestRes
        accuracy = 10
        testRes.k = 3
        testRes.b = 0

        for i in range(10):
            for a in range(1000):
                testRes.Test(inputs, outputs) #WARNING: May slow down
                wasErr = testRes.error
                testRes.k -= accuracy
                testRes.Test(inputs, outputs)
                if Module(wasErr) > Module(testRes.error): #if Module(wasErr) < Module(testRes.error):
                    ...
                else:
                    testRes.k += accuracy * 2 #To clear from -= before
                    testRes.Test(inputs, outputs)
                    if Module(wasErr) > Module(testRes.error):
                        testRes.k -= accuracy
            for a in range(1000):
                testRes.Test(inputs, outputs) #WARNING: May slow down
                wasErr = testRes.error
                testRes.b -= accuracy
                testRes.Test(inputs, outputs)
                if Module(wasErr) > Module(testRes.error): #if Module(wasErr) < Module(testRes.error):
                    ...
                else:
                    testRes.b += accuracy * 2 #To clear from -= before
                    testRes.Test(inputs, outputs)
                    if Module(wasErr) > Module(testRes.error):
                        testRes.k -= accuracy
            accuracy /= 10
            print(str((i + 1)*10) + "% done.(" + str(testRes.k) + "x + " + str(testRes.b) + ")")

        print("Done.")
        testRes.Test(inputs, outputs)
        self.bestRes.Test(inputs, outputs)
        if Module(testRes.error) < Module(self.bestRes.error):
            self.wasBestRes = self.bestRes
            self.bestRes = testRes

    def __init__(self, inputs, outputs):
        #mpl.rcParams['font.family'] = 'fantasy'
        self.inputs = inputs
        self.outputs = outputs
        #x = np.array(inputs)
        #y = np.array(outputs)
        #self.NewGuess(x, y) #self.mnkGP(inputs, outputs)
        self.Linear(inputs, outputs, 1000)

    def Predict(self, x):
        return self.bestRes.Predict(x)

def Sigmoid(x):
    return 1 / (1 + exp(-x))

def SigmoidDerivative(x):
    return x * (1 - x)

def NormalIndex(array, index):
    try:
        a = array[index]
        return True
    except:
        return False

#WARNING: Very unsafe class
class Neuron():
    inputs = 0
    weights = {}
    bias = 0
    def Sigmoid(self, x):
        return 1 / (1 + exp(-x))
    def SigmoidDerivative(self, x):
        return x * (1 - x)

    def __init__(self, weightsNumber):
        self.weights = [None] * weightsNumber#[random.random()] * weightsNumber #{}[321] #weights[weightsNumber] = {}
        self.inputs = weightsNumber
        
        #WARNING: Was commented:
        a = 0
        while a < weightsNumber:
            self.weights[a] = random.random()
            a += 1
        #WARNING end.

    def RandomizeWeights(self):
        a = 0
        while a < self.inputs:
            self.weights[a] = random.random()
            a += 1

    def Predict(self, input, inputNeuronIndex):
        output = self.Sigmoid(input * self.weights[inputNeuronIndex]) #WARNING
        return output
        
        try:
            output = [None] * self.inputs #output[inputs] = {}
            for i in range(self.inputs):
                output[i] = self.Sigmoid(input[i] * self.weights[i]) #WARNING
            return output
        except Exception as e:
            raise RuntimeError(e)

    def Feed(self, inputs):
        #print(" Neuron weights:", self.weights)
        output = 0
        try:
            a = 0
            #WARNING: Test function.
            while NormalIndex(inputs, a):
                try:
                    output += inputs[a]*self.weights[a]
                except Exception as e:
                    #WAS UNKOMMENTED:
                    #print("Exception happend: it may be because of inputs to neuron is too much or not enough!", e, a)
                    pass
                a += 1
            '''
            for i in inputs: #WARNING: #range(inputs): # + 1:
                #WARNING
                try:
                    output += inputs[i]*self.weights[i]
                except Exception as e:
                    print("EXCEPTIOON!!!", e, i)
                    pass
                #output[i] = self.Sigmoid(inputs[i]*weights[i])
            '''
        except Exception as e:
            #WAS UNKOMMENTED:
            #print("inputs:", inputs, "weights:", self.weights, e)
            #inputs variable is maybe not an array but an number:
            output = inputs * self.weights[0] #self.weights
        #FOR DEBUGGING WAS UNKOMMENTED:
        #print("Weights:", self.weights)
        #print("Before sigmoid:", output)
        #output = self.Sigmoid(output + self.bias)
        #print("After sigmoid:", output)
        #print("  Input:", inputs, "\n  Output:", output)
        return output

    def __str__(self):
        return "Neuron[" + str(self.weights) + "]"

    def __repr__(self):
        return "N[" + str(self.weights).replace('[', '').replace(']', '') + "]" #return super().__repr__()

class Network():
    neurons = {}
    lastLayer = 0 
    neuronsSummary = 0
    def __init__(self, startNeuronNum):
        self.neurons = {}
        self.lastLayer = 0
        self.neuronsSummary += startNeuronNum

        layer = [Neuron(1)] * startNeuronNum #neuronsNum
        self.neurons[self.lastLayer] = layer
        self.lastLayer += 1

    def Prepaire(self):
        for lc in range(len(self.neurons)):
            for nc in range(len(self.neurons[lc])):
                try:
                    self.neurons[lc][nc].RandomizeWeights() #Randomize()
                except Exception as e:
                    print("Exception happens while prepairing;", lc, "layer,", nc, "neuron:", e)

    def AddLayer(self, neuronsNum):
        if neuronsNum <= 0:
            raise IndexError("Incorrect index.")
        self.neuronsSummary += neuronsNum
        if self.lastLayer == 1: #INTERESTING why not lastLayer
            layer = [Neuron(len(self.neurons[0]))] * neuronsNum # + 1)] * neuronsNum #WARNING: Maybe " + 1" is not right
            #firstLayer = neurons[0]
            for i in range(len(self.neurons[0])): #WARNING with len()
                self.neurons[0][i] = Neuron(neuronsNum)
            self.neurons[self.lastLayer] = layer
            self.lastLayer += 1
        else:
            layer = [Neuron(len(self.neurons[self.lastLayer - 1]))] * neuronsNum #WARNING: " + 1"
            self.neurons[self.lastLayer] = layer
            self.lastLayer += 1

    def Predict(self, inputs):
        layerC = 0
        newInp = {}
        while layerC < self.lastLayer - 1: #WARNING: " - 1"
            #print("Layer counter:", layerC)
            for nc in range(len(self.neurons[layerC])):
                #print(" Using neuron number:", nc)
                newInp[nc] = self.neurons[layerC][nc].Feed(inputs)
                #print(" New inputs:", newInp)

            inputs = newInp
            newInp = {}
            layerC += 1
        return inputs
            
    '''
    def Predict(input, layerID):
        layerCounter = layerID
        while layerCounter in range(self.lastLayer - 1):
            for neuronCounter in range(len(input)):
                Predict(neurons[layerCounter][neuronCounter].Predict(input), layerCounter + 1) #WARNING: " + 1"
        layerCounter += 1;

    def Predict(self, input):
        helpVar = {}
        return
        for layerCounter in range(self.lastLayer - 1):
            for neuron2Counter in range(len(input)):
                for neuronCounter in range(len(input)):
                    helpVar[neuron2Counter] = Sigmoid(dot(input * self.neurons[layerCounter][neuronCounter].weights))
    '''
    def Learn(input, output):
        error = output - Predict(input)

    def __str__(self):
        return "Basic network[" + str(self.lastLayer) + " layers; " + str(self.neuronsSummary) + " total neurons]" #'''len(self.neurons + 1)'''

class N():
    weight = rand.random()
    def __init__(self, trainInputs, trainOutputs):
        actualResult = trainInputs * self.weight
        error = trainOutputs - actualResult
        correction = error / actualResult
        self.weight += correction

    def Train(self, trainInputs, trainOutputs):
        actualResult = trainInputs * self.weight
        error = trainOutputs - actualResult
        correction = error / actualResult
        self.weight += correction

    def Predict(self, x):
        return x * self.weight

def ShowGraph(x1, y1, x2, y2):
    plt.plot(x1, y1, label = "Dataset") 
 
    plt.plot(x2, y2, label = "Guessed result") 
  
    plt.xlabel("x axis") 
    plt.ylabel("y axis") 
    plt.title("Prediction") 
  
    plt.legend() 
  
    plt.show()

def ErrorAverage(k, b, x, y):
    error = 0
    for index in range(len(x)): #WARNING: Or y. If x and y are defferent types or lengths may cause error.
        error = error + ((k*x[index] + b) - y[index]) / 2
    
    return error

def Module(x):
    if x < 0:
        return x * -1
    else:
        return x

def GuessLinearFunc(Xtrain, Ytrain, maxRange, minRange):
    k = minRange
    b = minRange
    results = [[[0 for _ in range(maxRange)] for _ in range(maxRange)] for _ in range(maxRange)]
    merr = 1000000

    for testK in range(maxRange):
        for testB in range(maxRange):
            for res in range(maxRange):
                results[testK][testB][res] = ErrorAverage(testK, testB, Xtrain, Ytrain)
                if Module(results[testK][testB][res]) < Module(merr):
                    #print(merr, "to", results[testK][testB][res])
                    merr = results[testK][testB][res]
                    k = testK
                    b = testB

    return [k, b, merr]

LinearGuessingProgress = 0
def GuessLinearFuncProgress(Xtrain, Ytrain, maxRange, minRange = 0, step = 1):
    global LinearGuessingProgress
    if step == 0:
        step = 1
    merr = 1000000000
    testK = float(minRange)
    testB = float(minRange)

    LinearGuessingProgress = 0
    calculationRange = maxRange - minRange

    hMinRange = 0
    if minRange < 0:
        hMaxRange = maxRange + 0 - minRange
    else:
        hMaxRange = calculationRange

    while testK < maxRange + step:
        testB = minRange
        while testB < maxRange + step:
            if Module(ErrorAverage(testK, testB, Xtrain, Ytrain)) < Module(merr):
                merr = ErrorAverage(testK, testB, Xtrain, Ytrain)
                k = testK
                b = testB
                if merr == 0:
                    LinearGuessingProgress = 100
                    return [k, b, merr]

            testB = (testB*10 + step*10)/10 #WARNING: Untested. Made because of problem: "0.1 + 0.2"
        testK = (testK*10 + step*10)/10
        LinearGuessingProgress = int(((testK + hMaxRange) * 100) / (maxRange + step + hMaxRange))
        #Maybe better check if int(testK * 100 / maxRange) is more then LinearGuessingProgress
        #print(str(LinearGuessingProgress) + "%")

    return [k, b, merr]

def GuessLinearFuncAdv(Xtrain, Ytrain, maxRange, minRange = 0, step = 1, showProgress=False):
    if step == 0:
        step = 1
    if showProgress:
        return GuessLinearFuncProgress(Xtrain, Ytrain, maxRange, minRange, step)
    merr = 1000000000
    testK = float(minRange)
    testB = float(minRange)

    while testK < maxRange + step:
        testB = minRange
        while testB < maxRange + step:
            if Module(ErrorAverage(testK, testB, Xtrain, Ytrain)) < Module(merr):
                merr = ErrorAverage(testK, testB, Xtrain, Ytrain)
                k = testK
                b = testB
                if merr == 0:
                    return [k, b, merr]

            testB = (testB*10 + step*10)/10 #WARNING: Untested. Made because of problem: "0.1 + 0.2"
        testK = (testK*10 + step*10)/10

    return [k, b, merr]

def GuessLinearFuncHard(Xtrain, Ytrain, maxRange, minRange = 0, step = 1):
    if step == 0:
        step = 1
    if maxRange < minRange:
        raise "Error: maxRange dont needs to be smaller then minRange."
    merr = 1000000000
    testK = float(minRange)
    testB = float(minRange)

    while testK < maxRange + step:
        testB = minRange
        while testB < maxRange + step:
            if Module(ErrorAverage(testK, testB, Xtrain, Ytrain)) < Module(merr):
                merr = ErrorAverage(testK, testB, Xtrain, Ytrain)
                k = testK
                b = testB
                if merr == 0:
                    return [k, b, merr]

            testB = (testB*10 + step*10)/10 #WARNING: Untested. Made because of problem: "0.1 + 0.2"
        testK = (testK*10 + step*10)/10

    return [k, b, merr]


class tn:
    def __init__(self):
        self.w1 = rand.random()
        self.w2 = rand.random()
    def Predict(self, inp1, inp2):
        return [self.w1 * inp1, self.w2 * inp2]
import time
if __name__ == "__main__":
    n = tn()
    print("Prediction:", n.Predict(5, 3))
    exampleLength = 500
    x = [None] * exampleLength
    y = [None] * exampleLength
    c = 0
    k = 1
    b = -12
    
    while c < exampleLength:
        x[c] = c
        y[c] = (c*k + b) + rand.random()
        c += 1
    
    tStart = time.time()
    import threading
    from multiprocessing.pool import ThreadPool

    pool = ThreadPool(processes=1)

    pool.apply_async(LinearGuessingProgress, ('world', 'foo')) #x = threading.Thread(target=GuessLinearFuncAdv, args=(x, y, 85, -75, 0.5, True))
    #x.start()
    #prediction = GuessLinearFuncAdv(x, y, 85, -75, 0.5, True)
    c = 0
    while x.is_alive:
        if LinearGuessingProgress % 2 == 0 and c != LinearGuessingProgress:
            print(str(LinearGuessingProgress) + "%")
            c = LinearGuessingProgress
    x.join()
    #Show results
    print(prediction, "~Time:", time.time() - tStart)
    x2 = [None] * exampleLength
    y2 = [None] * exampleLength
    for index in range(len(x2)):
        x2[index] = x[index]
        y2[index] = x[index]*prediction[0] + prediction[1]
    ShowGraph(x, y, x2, y2)
    
#Simple chat-bot:
'''
data = {"Hi": "Hello"}

while True:
    inp = input("> ")
    try:
        print(data[inp])
    except:
        data[inp] = input("< ")
'''