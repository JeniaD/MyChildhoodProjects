import Basics
from Basics import *

import copy
import random

import os

class Node:
    def __init__(self, data, branchings = []):
        self.branchings = branchings
        #self.branchings = self.branchings #Make something like pointer to branchings. It may be changed automaticaly.
        self.data = data
    def AddBranch(self, object):
        self.branchings += [Node(object, [])]
    def AddBud(self, object):
        self.branchings += object

    def Erase(self):
        self.data = None
    def Clear(self):
        self.branchings = []

class Position:
    def __init__(self, x = None, y = None):
        self.x = x
        self.y = y

calculationDeep = 10
chess = Chess()
#Variable chess can be changed after, data in Node now will be automatically changed(maybe).
now = Node(chess)

def AddWays(branch, enemy = False):
    worstScore = 0
    for y in range(8):
        for x in range(8):
            if chess.board[y][x] > EMPTY and enemy == False:
                results = PossibleMooves(chess, x, y)
                for index in range(len(results)):
                    branch.AddBranch(results[index])
                    if results[index].GetStatus() < worstScore:
                        worstScore = results[index].GetStatus()
            elif chess.board[y][x] < EMPTY and enemy == True:
                results = PossibleMooves(chess, x, y)
                for index in range(len(results)):
                    branch.AddBranch(results[index])
                    if results[index].GetStatus() < worstScore:
                        worstScore = results[index].GetStatus()
    return worstScore

def Ways(possibility, enemy = False):
    branch = copy.deepcopy(possibility)
    for y in range(8):
        for x in range(8):
            if chess.board[y][x] > EMPTY and enemy == False:
                results = PossibleMooves(chess, x, y)
                for index in range(len(results)):
                    branch.AddBranch(results[index])
            elif chess.board[y][x] < EMPTY and enemy == True:
                results = PossibleMooves(chess, x, y)
                for index in range(len(results)):
                    branch.AddBranch(results[index])
#'Node' object has no attribute 'branchings'

#print(AddWays(now))
#print("Ways added.")

while True:
    print("[?] Calculating moves...")
    AddWays(now)
    print("Possible moves found:", len(now.branchings))
    MooveScore = -10000
    Moove = Chess()

    bestResults = []

    for a in range(len(now.branchings)):
        res = AddWays(now.branchings[a], True)
        if res > MooveScore:
            Moove = now.branchings[a].data
            MooveScore = Moove.GetStatus()
        elif res == MooveScore:
            bestResults += [now.branchings[a].data]
    bestResults += [Moove]


    #print(len(results))
    res = random.choice(bestResults)

    #Calculate the move for output and applying. 13 - 33
    mfrom = Position()
    mto = Position()
    
    for x in range(8):
        for y in range(8):
            if res.board[y][x] != chess.board[y][x]:
                if res.board[y][x] == EMPTY:
                    mfrom.x = x
                    mfrom.y = y
                if res.board[y][x] > EMPTY: #WARNING: May be not secure.
                    mto.x = x
                    mto.y = y
                    break

    chess.Moove(mfrom.x, mfrom.y, mto.x, mto.y)
    chess.Print()

    while True:
        try:
            print("\nMade move from", str(mfrom.x + 1) + ", " + str(mfrom.y + 1), "to", str(mto.x + 1) + ", " + str(mto.y + 1) + ".")
            inpx = input("x: ")
            inpy = input("y: ")
            inpx2 = input("x2: ")
            inpy2 = input("y2: ")

            now = None
            #print(chess.board[inpy][inpx], "to", chess.board[inpy2][inpx2])
            chess.Moove(int(inpx) - 1, int(inpy) - 1, int(inpx2) - 1, int(inpy2) - 1)
            break
        except Exception as e:
            print(e)
    #Clear for next iteration:
    now = Node(chess)

    
'''
print(len(now.branchings))

executionCode = ""
iteratorNumber = 0

exec(executionCode)
print(RES)
#for c in range(calculationDeep*2):
#    for ix in range(len(now.branchings)):
'''
while True:
    try:
        exec(input(">"))
    except Exception as e:
        print(e)

'''
for y in range(8):
    for x in range(8):
        
'''
