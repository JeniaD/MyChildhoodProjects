import array
import os

EMPTY = 0

PAWN = 2
ROOK = 17
KNIGHT = 10
BISHOP = 14
QUEEN = 45
KING = 60

ENEMYPAWN = -2
ENEMYROOK = -17
ENEMYKNIGHT = -10
ENEMYBISHOP = -14
ENEMYQUEEN = -45
ENEMYKING = -60

allyes = [PAWN, ROOK, KNIGHT, BISHOP, QUEEN, KING]
enemyes = [ENEMYPAWN, ENEMYROOK, ENEMYKNIGHT, ENEMYBISHOP, ENEMYQUEEN, ENEMYKING]
units = [PAWN, ROOK, KNIGHT, BISHOP, QUEEN, KING, ENEMYPAWN, ENEMYROOK, ENEMYKNIGHT, ENEMYBISHOP, ENEMYQUEEN, ENEMYKING]

def GetStatus(b):
        result = 0
        for y in range(8):
            for x in range(8):
                result += b[y][x]
        return result

#print(file=..., ...)
#import sys 
#from termcolor import cprint 

#Note that x and y is not correct:
#  0 2 3 4 5... 
#0 +- - - -  <-x
#1 |
#2 |
#3 |
# y
class Chess:
    def __init__(self):
        self.board = [[ROOK, KNIGHT, BISHOP, QUEEN, KING, BISHOP, KNIGHT, ROOK], [PAWN for i in range(8)], [EMPTY for i in range(8)], [EMPTY for i in range(8)], [EMPTY for i in range(8)], [EMPTY for i in range(8)], [ENEMYPAWN for i in range(8)], [ENEMYROOK, ENEMYKNIGHT, ENEMYBISHOP, ENEMYKING, ENEMYQUEEN, ENEMYBISHOP, ENEMYKNIGHT, ENEMYROOK]]

    def GetStatus(self):
        result = 0
        for y in range(8):
            for x in range(8):
                result += self.board[y][x]
        return result

    def WriteBoard(self):
        self.Print(self.board)

    def Moove(self, x1, y1, x2, y2):
        if x1 >= 8 or x1 < 0 or x2 >= 8 or x2 < 0 or y1 >= 8 or y1 < 0 or y2 >= 8 or y2 < 0:
            raise IndexError("Parameter is not correct.")
            return
        #WARNING: Not checking if moove correct.
        if self.board[y1][x1] < EMPTY and self.board[y2][x2] < EMPTY:
            raise IndexError("Move is not correct.")
        if self.board[y1][x1] > EMPTY and self.board[y2][x2] > EMPTY:
            raise IndexError("Move is not correct.")
        self.board[y2][x2] = self.board[y1][x1]
        self.board[y1][x1] = EMPTY

    def Inverse(self):
        for y in range(8):
            for x in range(8):
                target = self.board[y][x]
                if target == PAWN:
                    target = ENEMYPAWN
                elif target == ROOK:
                    target = ENEMYROOK
                elif target == KNIGHT:
                    target = ENEMYKNIGHT
                elif target == BISHOP:
                    target = ENEMYBISHOP
                elif target == KING:
                    target = ENEMYKING
                elif target == QUEEN:
                    target = ENEMYQUEEN

                elif target == ENEMYPAWN:
                    target = PAWN
                elif target == ENEMYROOK:
                    target = ROOK
                elif target == ENEMYKNIGHT:
                    target = KNIGHT
                elif target == ENEMYBISHOP:
                    target = BISHOP
                elif target == ENEMYKING:
                    target = KING
                elif target == ENEMYQUEEN:
                    target = QUEEN

    def Print(self):
        try:
            b[0][0] = b[0][0]
        except:
            b = copy.deepcopy(self.board) #WARNING copy.deepcopy may be slow.
            for y in range(8):
                for x in range(8):
                    if b[y][x] > 0:
                        if b[y][x] == PAWN:
                            print(" P ", end='', sep='')
                        elif b[y][x] == ROOK:
                            print(" R ", end='', sep='')
                        elif b[y][x] == KNIGHT:
                            print(" k ", end='', sep='')
                        elif b[y][x] == BISHOP:
                            print(" B ", end='', sep='')
                        elif b[y][x] == QUEEN:
                            print(" Q ", end='', sep='')
                        elif b[y][x] == KING:
                            print(" K ", end='', sep='')
                        else:
                            print(b[y][x], end='', sep='')
                    elif b[y][x] < 0:
                        if b[y][x] == ENEMYPAWN:
                            print("eP ", end='', sep='')
                        elif b[y][x] == ENEMYROOK:
                            print("eR ", end='', sep='')
                        elif b[y][x] == ENEMYKNIGHT:
                            print("ek ", end='', sep='')
                        elif b[y][x] == ENEMYBISHOP:
                            print("eB ", end='', sep='')
                        elif b[y][x] == ENEMYQUEEN:
                            print("eQ ", end='', sep='')
                        elif b[y][x] == ENEMYKING:
                            print("eK ", end='', sep='')
                        else:
                            print(b[y][x], end='', sep='')
                    else:
                        print("<E>", end = '', sep = '') #b[y][x], end='', sep='')
                print()

import copy
def PossibleMooves(chessBoard, x, y):
    index = 0
    possibleMooves = []
    target = chessBoard.board[y][x]
    if target == EMPTY:
        return possibleMooves

    helpVar = copy.deepcopy(chessBoard)

    #Enemy is downside. In enemy mooves needs to be y - 1(not +1)
    if target == PAWN:
        try:
            if helpVar.board[y + 1][x] == EMPTY:
                helpVar.Moove(x, y, x, y + 1)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ... #print(e)
        try:
            if helpVar.board[y + 1][x + 1] < EMPTY:
                helpVar.Moove(x, y, x + 1, y + 1)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ... #print(e)
        try:
            if helpVar.board[y + 1][x - 1] < EMPTY:
                helpVar.Moove(x, y, x - 1, y + 1)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ... #print(e)
        try:
            if helpVar.board[y + 2][x] == EMPTY and y == 1: #If pawn is on start location.
                helpVar.Moove(x, y, x, y + 2)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ... #print(e)
    elif target == ROOK:
        try:
            stepSize = 1
            while helpVar.board[y + stepSize][x] <= EMPTY: 
                helpVar.Moove(x, y, x, y + stepSize)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY: #Or <=
                    break
        except IndexError as e:
            ...
        try:
            stepSize = 1
            while helpVar.board[y - stepSize][x] <= EMPTY: 
                helpVar.Moove(x, y, x, y - stepSize)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY:
                    break
        except IndexError as e:
            ...
        try:
            stepSize = 1
            while helpVar.board[y][x - stepSize] <= EMPTY: 
                helpVar.Moove(x, y, x - stepSize, y)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY:
                    break
        except IndexError as e:
            ...
        try:
            stepSize = 1
            while helpVar.board[y][x + stepSize] <= EMPTY: 
                helpVar.Moove(x, y, x + stepSize, y)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY:
                    break
        except IndexError as e:
            ...
    elif target == KNIGHT:
        try:
            if helpVar.board[y + 2][x + 1] <= EMPTY:
                helpVar.Moove(x, y, x + 1, y + 2)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        try:
            if helpVar.board[y + 2][x - 1] <= EMPTY:
                helpVar.Moove(x, y, x - 1, y + 2)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        try:
            if helpVar.board[y + 1][x + 2] <= EMPTY:
                helpVar.Moove(x, y, x + 2, y + 1)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        try:
            if helpVar.board[y + 1][x - 2] <= EMPTY:
                helpVar.Moove(x, y, x - 2, y + 1)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        try:
            if helpVar.board[y - 2][x + 1] <= EMPTY:
                helpVar.Moove(x, y, x + 1, y - 2)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        try:
            if helpVar.board[y - 2][x - 1] <= EMPTY:
                helpVar.Moove(x, y, x - 1, y - 2)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        try:
            if helpVar.board[y - 1][x + 2] <= EMPTY:
                helpVar.Moove(x, y, x + 2, y - 1)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        try:
            if helpVar.board[y - 1][x - 2] <= EMPTY:
                helpVar.Moove(x, y, x - 2, y - 1)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
    elif target == BISHOP:
        try:
            stepSize = 1
            while helpVar.board[y - stepSize][x - stepSize] <= EMPTY: 
                helpVar.Moove(x, y, x + stepSize, y - stepSize)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY: #Or <=
                    break
        except IndexError as e:
            ...
        try:
            stepSize = 1
            while helpVar.board[y - stepSize][x + stepSize] <= EMPTY: 
                helpVar.Moove(x, y, x + stepSize, y - stepSize)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY:
                    break
        except IndexError as e:
            ...
        try:
            stepSize = 1
            while helpVar.board[y + stepSize][x - stepSize] <= EMPTY: 
                helpVar.Moove(x, y, x - stepSize, y + stepSize)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY:
                    break
        except IndexError as e:
            ...
        try:
            stepSize = 1
            while helpVar.board[y + stepSize][x + stepSize] <= EMPTY: 
                helpVar.Moove(x, y, x + stepSize, y + stepSize)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY:
                    break
        except IndexError as e:
            ...
    elif target == KING:
        #Up(or may be down...)
        try:
            if helpVar.board[y + 1][x] <= EMPTY:
                helpVar.Moove(x, y, x, y + 1)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        #Down(or may be up...)
        try:
            if helpVar.board[y - 1][x] <= EMPTY:
                helpVar.Moove(x, y, x, y - 1)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        #Left
        try:
            if helpVar.board[y][x - 1] <= EMPTY:
                helpVar.Moove(x, y, x - 1, y)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        #Right
        try:
            if helpVar.board[y][x + 1] <= EMPTY:
                helpVar.Moove(x, y, x + 1, y)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        #Up-left
        try:
            if helpVar.board[y + 1][x - 1] <= EMPTY:
                helpVar.Moove(x, y, x - 1, y + 1)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        #Up-right
        try:
            if helpVar.board[y + 1][x + 1] <= EMPTY:
                helpVar.Moove(x, y, x + 1, y + 1)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        #Down-left
        try:
            if helpVar.board[y - 1][x - 1] <= EMPTY:
                helpVar.Moove(x, y, x - 1, y - 1)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        #Down-right
        try:
            if helpVar.board[y - 1][x + 1] <= EMPTY:
                helpVar.Moove(x, y, x + 1, y + 1)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
    elif target == QUEEN:
        try:
            stepSize = 1
            while helpVar.board[y + stepSize][x] <= EMPTY: 
                helpVar.Moove(x, y, x, y + stepSize)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY: #Or <=
                    break
        except IndexError as e:
            ...
        try:
            stepSize = 1
            while helpVar.board[y - stepSize][x] <= EMPTY: 
                helpVar.Moove(x, y, x, y - stepSize)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY:
                    break
        except IndexError as e:
            ...
        try:
            stepSize = 1
            while helpVar.board[y][x - stepSize] <= EMPTY: 
                helpVar.Moove(x, y, x - stepSize, y)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY:
                    break
        except IndexError as e:
            ...
        try:
            stepSize = 1
            while helpVar.board[y][x + stepSize] <= EMPTY: 
                helpVar.Moove(x, y, x + stepSize, y)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY:
                    break
        except IndexError as e:
            ...

        try:
            stepSize = 1
            while helpVar.board[y - stepSize][x - stepSize] <= EMPTY: 
                helpVar.Moove(x, y, x + stepSize, y - stepSize)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY: #Or <=
                    break
        except IndexError as e:
            ...
        try:
            stepSize = 1
            while helpVar.board[y - stepSize][x + stepSize] <= EMPTY: 
                helpVar.Moove(x, y, x + stepSize, y - stepSize)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY:
                    break
        except IndexError as e:
            ...
        try:
            stepSize = 1
            while helpVar.board[y + stepSize][x - stepSize] <= EMPTY: 
                helpVar.Moove(x, y, x - stepSize, y + stepSize)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY:
                    break
        except IndexError as e:
            ...
        try:
            stepSize = 1
            while helpVar.board[y + stepSize][x + stepSize] <= EMPTY: 
                helpVar.Moove(x, y, x + stepSize, y + stepSize)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY:
                    break
        except IndexError as e:
            ...
    
    if target == ENEMYPAWN:
        try:
            if helpVar.board[y - 1][x] == EMPTY:
                helpVar.Moove(x, y, x, y - 1)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ... #print(e)
        try:
            if helpVar.board[y - 1][x - 1] > EMPTY:
                helpVar.Moove(x, y, x - 1, y - 1)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ... #print(e)
        try:
            if helpVar.board[y - 1][x + 1] > EMPTY:
                helpVar.Moove(x, y, x + 1, y - 1)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ... #print(e)
        try:
            if helpVar.board[y - 2][x] == EMPTY and y == 6: #If pawn is on start location.
                helpVar.Moove(x, y, x, y - 2)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ... #print(e)
    elif target == ENEMYROOK:
        try:
            stepSize = 1
            while helpVar.board[y - stepSize][x] >= EMPTY: 
                helpVar.Moove(x, y, x, y - stepSize)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY: #Or >=
                    break
        except IndexError as e:
            ...
        try:
            stepSize = 1
            while helpVar.board[y + stepSize][x] >= EMPTY: 
                helpVar.Moove(x, y, x, y + stepSize)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY:
                    break
        except IndexError as e:
            ...
        try:
            stepSize = 1
            while helpVar.board[y][x + stepSize] >= EMPTY: 
                helpVar.Moove(x, y, x + stepSize, y)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY:
                    break
        except IndexError as e:
            ...
        try:
            stepSize = 1
            while helpVar.board[y][x - stepSize] >= EMPTY: 
                helpVar.Moove(x, y, x - stepSize, y)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY:
                    break
        except IndexError as e:
            ...
    elif target == ENEMYKNIGHT:
        try:
            if helpVar.board[y - 2][x - 1] >= EMPTY:
                helpVar.Moove(x, y, x - 1, y - 2)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        try:
            if helpVar.board[y - 2][x + 1] >= EMPTY:
                helpVar.Moove(x, y, x + 1, y - 2)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        try:
            if helpVar.board[y - 1][x - 2] >= EMPTY:
                helpVar.Moove(x, y, x - 2, y - 1)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        try:
            if helpVar.board[y - 1][x + 2] >= EMPTY:
                helpVar.Moove(x, y, x + 2, y - 1)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        try:
            if helpVar.board[y + 2][x - 1] >= EMPTY:
                helpVar.Moove(x, y, x - 1, y + 2)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        try:
            if helpVar.board[y + 2][x + 1] >= EMPTY:
                helpVar.Moove(x, y, x + 1, y + 2)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        try:
            if helpVar.board[y + 1][x - 2] >= EMPTY:
                helpVar.Moove(x, y, x - 2, y + 1)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        try:
            if helpVar.board[y + 1][x + 2] >= EMPTY:
                helpVar.Moove(x, y, x + 2, y + 1)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
    #Unpolar-changed
    elif target == ENEMYBISHOP: 
        try:
            stepSize = 1
            while helpVar.board[y - stepSize][x - stepSize] >= EMPTY: 
                helpVar.Moove(x, y, x + stepSize, y - stepSize)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY: #Or >=
                    break
        except IndexError as e:
            ...
        try:
            stepSize = 1
            while helpVar.board[y - stepSize][x + stepSize] >= EMPTY: 
                helpVar.Moove(x, y, x + stepSize, y - stepSize)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY:
                    break
        except IndexError as e:
            ...
        try:
            stepSize = 1
            while helpVar.board[y + stepSize][x - stepSize] >= EMPTY: 
                helpVar.Moove(x, y, x - stepSize, y + stepSize)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY:
                    break
        except IndexError as e:
            ...
        try:
            stepSize = 1
            while helpVar.board[y + stepSize][x + stepSize] >= EMPTY: 
                helpVar.Moove(x, y, x + stepSize, y + stepSize)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY:
                    break
        except IndexError as e:
            ...
    #Unpolar-changed
    elif target == ENEMYKING:
        #Up(or may be down...)
        try:
            if helpVar.board[y + 1][x] >= EMPTY:
                helpVar.Moove(x, y, x, y + 1)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        #Down(or may be up...)
        try:
            if helpVar.board[y - 1][x] >= EMPTY:
                helpVar.Moove(x, y, x, y - 1)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        #Left
        try:
            if helpVar.board[y][x - 1] >= EMPTY:
                helpVar.Moove(x, y, x - 1, y)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        #Right
        try:
            if helpVar.board[y][x + 1] >= EMPTY:
                helpVar.Moove(x, y, x + 1, y)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        #Up-left
        try:
            if helpVar.board[y + 1][x - 1] >= EMPTY:
                helpVar.Moove(x, y, x - 1, y + 1)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        #Up-right
        try:
            if helpVar.board[y + 1][x + 1] >= EMPTY:
                helpVar.Moove(x, y, x + 1, y + 1)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        #Down-left
        try:
            if helpVar.board[y - 1][x - 1] >= EMPTY:
                helpVar.Moove(x, y, x - 1, y - 1)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
        #Down-right
        try:
            if helpVar.board[y - 1][x + 1] >= EMPTY:
                helpVar.Moove(x, y, x + 1, y + 1)
                possibleMooves += [helpVar]
                index += 1
                helpVar = copy.deepcopy(chessBoard)
        except IndexError as e:
            ...
    elif target == ENEMYQUEEN:
        try:
            stepSize = 1
            while helpVar.board[y + stepSize][x] >= EMPTY: 
                helpVar.Moove(x, y, x, y + stepSize)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY: #Or >=
                    break
        except IndexError as e:
            ...
        try:
            stepSize = 1
            while helpVar.board[y - stepSize][x] >= EMPTY: 
                helpVar.Moove(x, y, x, y - stepSize)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY:
                    break
        except IndexError as e:
            ...
        try:
            stepSize = 1
            while helpVar.board[y][x - stepSize] >= EMPTY: 
                helpVar.Moove(x, y, x - stepSize, y)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY:
                    break
        except IndexError as e:
            ...
        try:
            stepSize = 1
            while helpVar.board[y][x + stepSize] >= EMPTY: 
                helpVar.Moove(x, y, x + stepSize, y)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY:
                    break
        except IndexError as e:
            ...

        try:
            stepSize = 1
            while helpVar.board[y - stepSize][x - stepSize] >= EMPTY: 
                helpVar.Moove(x, y, x + stepSize, y - stepSize)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY: #Or >=
                    break
        except IndexError as e:
            ...
        try:
            stepSize = 1
            while helpVar.board[y - stepSize][x + stepSize] >= EMPTY: 
                helpVar.Moove(x, y, x + stepSize, y - stepSize)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY:
                    break
        except IndexError as e:
            ...
        try:
            stepSize = 1
            while helpVar.board[y + stepSize][x - stepSize] >= EMPTY: 
                helpVar.Moove(x, y, x - stepSize, y + stepSize)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY:
                    break
        except IndexError as e:
            ...
        try:
            stepSize = 1
            while helpVar.board[y + stepSize][x + stepSize] >= EMPTY: 
                helpVar.Moove(x, y, x + stepSize, y + stepSize)
                possibleMooves += [helpVar]
                index += 1
                stepSize += 1
                helpVar = copy.deepcopy(chessBoard)
                if helpVar.board[y + stepSize][x] != EMPTY:
                    break
        except IndexError as e:
            ...

    #print("Returned results:", index, "for", target)
    return possibleMooves
