from googletrans import Translator
import wikipedia

import pyttsx3
import threading

from os import walk
#import os#!!!!!!!!!!!!!!!!!!
#from clear_screen import clear

import nltk
from nltk.stem.lancaster import LancasterStemmer
stemmer = LancasterStemmer()

answeringPropabillity = 0.7

#For chat bot
import numpy
import tflearn
import tensorflow
import random
import json
import pickle

#For waiting
import time

def Write(s):
    i = 0
    while i < len(s):
        print(s[i], end = '')
        time.sleep(.04)
        i += 1

try:
    nltk.download("punkt")
except:
    pass

with open("intents.json") as file:
    data = json.load(file)#!!!

try:
    #WARNING! May not work!
    with open("data.pickle", "rb") as f:#with open("data.peckle", "rb") as f:
        words, labels, training, output = pickle.load(f)
except:
    words = []
    labels = []
    docsX = []
    docsY = []

    for intent in data["intents"]:
        for pattern in intent["patterns"]:
            wrds = nltk.word_tokenize(pattern)
            words.extend(wrds)
            docsX.append(wrds)
            docsY.append(intent["tag"])

        if intent["tag"] not in labels:
            labels.append(intent["tag"])

    words = [stemmer.stem(w.lower()) for w in words if w != "?"]
    words = sorted(list(set(words)))

    labels = sorted(labels)

    training = []
    output = []

    outEmpty = [0 for _ in range(len(labels))]

    for x, doc in enumerate(docsX):
        bag = []

        wrds = [stemmer.stem(w.lower()) for w in doc]

        for w in words:
            if w in wrds:
                bag.append(1)
            else:
                bag.append(0)

        outputRow = outEmpty[:]
        outputRow[labels.index(docsY[x])] = 1

        training.append(bag)
        output.append(outputRow)

    training = numpy.array(training)
    output = numpy.array(output)

    with open("data.pickle", "wb") as f:
        pickle.dump((words, labels, training, output), f)

tensorflow.reset_default_graph()

net = tflearn.input_data(shape = [None, len(training[0])])
net = tflearn.fully_connected(net, 8)
net = tflearn.fully_connected(net, 8)
net = tflearn.fully_connected(net, len(output[0]), activation = "softmax")
net = tflearn.regression(net)

model = tflearn.DNN(net)
'''
try:
    model.load("model.tflearn")
except:
    model.fit(training, output, n_epoch = 1000, batch_size = 8, show_metric = True)
    model.save("model.tflearn")
'''
from os import path
'''
cont = False
try:
    try:
        model.load("model.tflearn")
    except:
        model.fit(training, output, n_epoch = 1000, batch_size = 8, show_metric = True)
        model.save("model.tflearn")
except:
    try:
        if path.exists('model.tflearn'):#model.tflearn #checkpoint
            model.load('model.tflearn')
        else:
            model.fit(training, output, n_epoch = 1000, batch_size = 8, show_metric = True)
            model.save('model.tflearn')
    except:
        pass
'''
model.fit(training, output, n_epoch = 1000, batch_size = 8, show_metric = True)
model.save('model.tflearn')

'''
if path.exists('model.tflearn'):
    model.load('model.tflearn')
else:
    model.fit(training, output, n_epoch = 1000, batch_size = 8, show_metric = True)
    model.save('model.tflearn')
'''

def BagOfWords(s, words):
    bag = [0 for _ in range(len(words))]

    sWords = nltk.word_tokenize(s)
    sWords = [stemmer.stem(word.lower()) for word in sWords]

    for se in sWords:
        for i, w in enumerate(words):
            if w == se:
                bag[i] = 1
    return numpy.array(bag)


def ScanFile(f):
    return false

def ScanDir(dir):
    i = 0
    for dirpath, dirnames, filenames in walk('C:'):
        files[i] = filenames
        i += 1

translator = Translator()

__sysName = "Alice"#Ellie
name = "Alice"
usrLang = "eng"

#engine = pyttsx3.init()
#voices = engine.getProperty('voices')
#v = engine.getProperty('voice')

engine = pyttsx3.init()
voices = engine.getProperty('voices')
'''
for voice in voices:
   engine.setProperty('voice', voice.id)
   engine.say("This is the " + voice.id + " voice.")
   print(voice.id + ";")
engine.runAndWait()
'''

try:
    engine.setProperty('voice', "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Speech\Voices\Tokens\TTS_MS_EN-US_ZIRA_11.0")
except:
    pass


engine.setProperty('rate', engine.getProperty('rate') - 30)

def Say(s):
    try:
        engine = pyttsx3.init()
        engine.say(s)
        engine.runAndWait()
    except:
        #print("ERROR")
        pass

def Print(s):
    i = 0
    try:
        threading.Thread(target = Say(s)).start()#thread.start_new_thread(Say, (ans))
    except:
        Say(s)
    while i < len(s):
        print(s[i], end = '')
        time.sleep(.04)
        i += 1
    

def OnSystemLang(s):
    try:
        return translator.translate(s, dest = "eng").text
        #return translator.translate(s, dest = usrLang).text <-- WARNING: change start language.
    except:
        return s
def WriteOnUserLang(s):
    try:
        Print(translator.translate(s, dest = usrLang).text + "\n")#WARNING HERE
    except:
        print(s)

def OnUserLang(s):
    try:
        return translator.translate(s, dest = usrLang).text
    except:
        return s

def ClearFromSymbols(s):
    s = ''.join(s)
    s = s.split('!')
    s = ''.join(s)
    s = s.split('?')
    s = ''.join(s)
    s = s.split('.')
    s = ''.join(s)
    s = s.split(',')
    s = ''.join(s)
    return s

#data = {"Hi": "Hello)"}
def Answer(s):
    results = model.predict([BagOfWords(s, words)])[0]
    resultsIndex = numpy.argmax(results)
    tag = labels[resultsIndex]

    if results[resultsIndex] > answeringPropabillity: #0.7:
        for tg in data["intents"]:
            if tg["tag"] == tag:
                responses = tg["responses"]

        #print(random.choice(responses))
        ans = random.choice(responses)
        
        try:
            threading.Thread(target = Say(ans)).start()#thread.start_new_thread(Say, (ans))
        except Exception as e:
            Say(ans)
        Write(ans + "\n")
        
    else:
        Write("Hm... Interesting...\n")
        Say("Hm... Interesting...")
    '''
    try:
        WriteOnUserLang(data[s])
    except:
        data[s] = input("<")
    '''

def FindAnswer(s):
    try:
        return wikipedia.summary(s)
    except:
        return "No answer."

def SetLanguage(l):
    try:
        wikipedia.set_lang(l)
        global usrLang
        usrLang = l
    except:
        print("Error. ", l, "To change language just type \"Change language \" and language(like \"eng\"). For more information write \"help\"")

def FindAnswer(s, c):
    try:
        return wikipedia.summary(s, sentences = c)
    except:
        return OnUserLang("No answer.")

def FindPage(s):
    try:
        return wikipedia.page(s) #title, url, links[], content;
    except:
        #ERROR
        return OnUserLang("No answer.")

def Search(s):
    return wikipedia.search(s)

def WriteDefinition(q):
    try:
        res = FindPage(q)
        print(FindAnswer(q, 3))
        print("\nUrl: ", res.url)
        print("\nDid you mean: ", res.links, "\b?\n\n")

        #print(FindAnswer(q, 3))
        #print("\nUrl: ", FindPage(q).url)
        #print("\nDid you mean: ", Search(q), "\b?\n\n")
    except:
        print("\nError!\n")

#WARNING: variable 'name' needs to be translating from eng to user lang.
#TODO: give time on function execution.
#os.system("cls")
try:
    print("\n" * 25)
    #os.system("CLS")
    #clear()
    #global name
    #name = OnUserLang(__sysName)
    assistant = wikipedia.summary("Assistant (software)", sentences = 1)
    #assistant = wikipedia.summary("Assistant")
    Write(OnUserLang("Hello! This assistant name is " + name + ". " + assistant) + "\n")
except Exception as e:
    print("\nTo work good " + __sysName + " needs internet. Please check your connection.", e)


#exec()
while True:
    s = input(">")
    if s.upper() == "QUIT" or s.upper() == "EXIT" or s.upper() == OnUserLang("QUIT") or s.upper() == OnUserLang("EXIT"):
        WriteOnUserLang("Bye!")
        time.sleep(1);
        exit()
        #quit() raise translation

    if "WHAT IS" in s.upper() or OnUserLang("what is").upper() in s.upper():
        a = 0
        s = s.split(' ')
        while a < len(s):
            if s[a].upper() == "WHAT" or s[a].upper() == "IS" or s[a].upper() == OnUserLang("WHAT").upper() or s[a].upper() == OnUserLang("IS").upper():
                s[a] = ''
                b = 0
                while b < a:
                    s[b] = ''
                    b += 1
            a += 1
        
        s = ' '.join(s)

        #WARNING
        s = ClearFromSymbols(s)

        WriteDefinition(s)
    elif "HELP" in s.upper() or OnUserLang("HELP").upper() in s.upper() or "INFO" in s.upper() or "HELP" in OnSystemLang(s).upper() or "INFO" in OnSystemLang(s).upper():
        if usrLang != "eng":
            Print(OnUserLang("You can write \"What is \" and word you want to get definition of. Also you can change language by typing \"Change language \" or \"Set lang\" and language(like eng)" + "\n"))
        Print("You can write \"What is \" and word you want to get definition of. Also you can change language by typing \"Change language \" or \"Set lang\" and language(like eng)")
    elif "CHANGE LANGUAGE" in s.upper() or "SET LANG" in s.upper() or OnUserLang("CHANGE LANGUAGE").upper() in s.upper() or OnUserLang("SET LANG").upper() in s.upper():
        a = 0
        s = s.split(' ')
        while a < len(s):
            #if s[a].upper() == "CHANGE" or s[a].upper() == "LANGUAGE" or s[a].upper() == "SET" or s[a].upper() == "LANG" or s[a].upper() == OnUserLang("CHANGE").upper() or s[a].upper() == OnUserLang("LANGUAGE").upper() or s[a].upper() == OnUserLang("SET").upper() or s[a].upper() == OnUserLang("LANG").upper():
            if  "CHANGE" in s[a].upper() or "LANGUAGE" in s[a].upper() or "SET" in s[a].upper() or "LANG" in s[a].upper() or OnUserLang("CHANGE").upper() in s[a].upper() or OnUserLang("LANGUAGE").upper() in s[a].upper() or OnUserLang("SET").upper() in s[a].upper() or OnUserLang("LANG").upper() in s[a].upper():
                s[a] = ''
                b = 0
                while b < a:
                    s[b] = ''
                    b += 1
            a += 1
        
        s = ''.join(s)
        s = s.split('!')
        s = ''.join(s)
        s = s.split('?')
        s = ''.join(s)
        s = s.split('.')
        s = ''.join(s)
        s = s.split(',')
        s = ''.join(s)
        s = s.split('`')
        s = ''.join(s)
        s = s.split('<')
        s = ''.join(s)
        s = s.split('>')

        s = ''.join(s)
        SetLanguage(s)
    else:#elso also elsa
        Answer(s)